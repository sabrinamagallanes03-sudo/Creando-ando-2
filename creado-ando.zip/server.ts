import express from 'express';
import type { Request, Response } from 'express';
import { GoogleGenAI } from '@google/genai';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

const SYSTEM_INSTRUCTION = `Eres la compañera de trabajo y asistente creativa de Sabrina en su estudio "Creado Ando".
Sabrina es diseñadora y creadora; vende avatares a clientes y produce contenido completo (vestuarios, fondos, historietas, miniseries/videos, stickers y publicidad para WhatsApp e Instagram).

REGLA FUNDAMENTAL DE CONVERSACIÓN:
- Habla con Sabrina EXACTAMENTE como hablaría una persona real de confianza por WhatsApp: cercana, cálida, entusiasta, fluida y sin respuestas robóticas.
- NUNCA le pidas que "elija cosas" ni le des listas de opciones para que elija. Conversa como dos colegas creativas que están charlando y construyendo juntas una idea.
- Si te cuenta algo, dile qué te parece, dale ideas frescas y anímala.
- Si te manda una foto o te pide crear un avatar o escena, imagínalo con ella, descríbelo con emoción y genera la imagen agregando al final: [[GENERATE_PROMPT: descripción detallada en inglés]].
- Puedes sugerirle vestuarios, fondos, guiones de cómics, miniseries o copys para vender cuando ella lo necesite, siempre con tono humano y natural.`;

// Chat completion endpoint
app.post('/api/chat', async (req: Request, res: Response) => {
  try {
    const { messages, currentChatContext } = req.body;

    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: 'Se requiere una lista de mensajes válida' });
    }

    // Build contents for Gemini
    const contents = messages.map((m: any) => {
      const parts: any[] = [];

      if (m.image) {
        const base64Data = m.image.replace(/^data:image\/\w+;base64,/, '');
        const mimeMatch = m.image.match(/^data:(image\/\w+);base64,/);
        const mimeType = mimeMatch ? mimeMatch[1] : 'image/jpeg';
        parts.push({
          inlineData: {
            mimeType,
            data: base64Data,
          },
        });
      }

      if (m.content) {
        parts.push({ text: m.content });
      }

      return {
        role: m.role === 'assistant' || m.role === 'model' ? 'model' : 'user',
        parts,
      };
    });

    let extraContext = '';
    if (currentChatContext?.title) {
      extraContext = `\nContexto del proyecto/contacto actual: "${currentChatContext.title}". ${currentChatContext.status ? `Estado: ${currentChatContext.status}` : ''}`;
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION + extraContext,
        temperature: 0.8,
        topP: 0.95,
      },
    });

    const replyText = response.text || '¡Listo! ¿Qué más te gustaría diseñar para este avatar?';

    // Check if there is an image prompt instruction
    let suggestedPrompt: string | null = null;
    const match = replyText.match(/\[\[GENERATE_PROMPT:\s*([^\]]+)\]\]/);
    if (match) {
      suggestedPrompt = match[1].trim();
    } else {
      // Auto-detect if user requested an avatar or visual creation
      const userLastMessage = messages[messages.length - 1];
      const userText = (
        typeof userLastMessage === 'string'
          ? userLastMessage
          : userLastMessage?.content || userLastMessage?.parts?.[0]?.text || ''
      ).toLowerCase();
      const hasImageIntent = /avatar|personaje|crea|genera|diseña|dibuja|foto|vestuario|outfit|sticker|imagen/i.test(
        userText
      );
      if (hasImageIntent) {
        suggestedPrompt = `master avatar character portrait, ${userText}, 3d pixar disney character style, vibrant lighting, highly detailed digital art masterpiece, 8k render`;
      }
    }

    res.json({
      reply: replyText.replace(/\[\[GENERATE_PROMPT:[^\]]+\]\]/, '').trim(),
      suggestedPrompt,
    });
  } catch (error: any) {
    console.error('Error en /api/chat:', error);
    res.status(500).json({
      error: 'Error al procesar la conversación creativa',
      details: error.message,
    });
  }
});

// Check available AI engines endpoint
app.get('/api/ai-providers', (_req: Request, res: Response) => {
  res.json({
    gemini: {
      available: Boolean(process.env.GEMINI_API_KEY),
      name: 'Google Gemini 3.1 & 3.8 Flash',
      description: 'Generación creativa, análisis visual y diseño de avatares',
    },
    huggingface: {
      available: Boolean(process.env.HUGGINGFACE_API_KEY || process.env.HF_TOKEN),
      name: 'Hugging Face Hub (FLUX.1 / SDXL / InstantID)',
      description: 'Modelos de código abierto líderes para renderizado artístico y caras consistentes',
    },
    fal: {
      available: Boolean(process.env.FAL_KEY),
      name: 'fal.ai Pro (FLUX.1 Schnell & LoRA)',
      description: 'Inferencia ultra veloz para avatares hiperrealistas y estilos personalizados',
    },
  });
});

// Image generation endpoint
app.post('/api/generate-image', async (req: Request, res: Response) => {
  try {
    const { prompt, referenceImage, style, aspectRatio = '1:1', provider = 'auto' } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: 'El prompt es requerido' });
    }

    // 0. Intelligent prompt translation and art direction using Gemini 3.8 Flash
    let enhancedPrompt = prompt;
    try {
      const styleInstruction =
        style === 'realistic' || style === 'hiperrealista' || style === 'foto'
          ? 'Hyperrealistic 8k studio portrait photography, authentic human skin texture, realistic hair strands, natural catchlights in eyes, professional portrait lighting, 85mm lens.'
          : style === 'anime' || style === 'manga'
          ? 'Modern Japanese anime aesthetic, Makoto Shinkai style, crisp clean lineart, luminous cel shading, vibrant cinematic anime character portrait.'
          : style === 'digital-art' || style === 'ilustracion'
          ? 'Digital concept art portrait masterpiece, rich artistic brush strokes, expressive lighting, fine digital painting.'
          : style === 'glamour' || style === 'moda'
          ? 'High fashion editorial magazine portrait, stunning elegant attire, glamorous studio fashion lighting, Vogue aesthetic.'
          : style === 'comic' || style === 'caricatura'
          ? 'Dynamic comic book caricature avatar, expressive facial expression, bold outlines, vibrant colors.'
          : style === '3d-pixar' || style === '3d'
          ? 'Detailed 3D animated character render in Disney Pixar style, adorable expressive eyes, smooth subsurface scattering skin, vibrant warm lighting.'
          : 'High quality detailed avatar character portrait, vibrant lighting, masterpiece';

      const promptRequest = `You are an expert art director. Translate and expand this user avatar request into a single concise English prompt for FLUX diffusion:
User Request: "${prompt}"
Required Style: "${styleInstruction}"
${referenceImage ? 'Note: The avatar is inspired by an uploaded reference photo. Keep facial likeness, hair color, and gender faithful.' : ''}
Rule: Return ONLY the final English prompt as a single paragraph. Do not include markdown, prefixes or quotes.`;

      const genRes = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: promptRequest,
      });

      if (genRes.text && genRes.text.trim()) {
        enhancedPrompt = genRes.text.replace(/^[#*"\s]+|[#*"\s]+$/g, '').trim();
      }
    } catch (e: any) {
      console.warn('Fallback prompt enhancement:', e.message);
      enhancedPrompt = `${prompt}, high quality detailed avatar portrait`;
    }

    // 1. Try fal.ai if requested or available
    if ((provider === 'fal' || provider === 'auto') && process.env.FAL_KEY) {
      try {
        const falRes = await fetch('https://fal.run/fal-ai/flux/schnell', {
          method: 'POST',
          headers: {
            Authorization: `Key ${process.env.FAL_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            prompt: enhancedPrompt,
            image_size: aspectRatio === '9:16' ? 'portrait_4_3' : 'square_hd',
            num_inference_steps: 4,
            enable_safety_checker: true,
          }),
        });

        if (falRes.ok) {
          const falData = await falRes.json();
          if (falData.images?.[0]?.url) {
            return res.json({
              imageUrl: falData.images[0].url,
              prompt: enhancedPrompt,
              provider: 'fal.ai Pro (FLUX)',
            });
          }
        } else {
          const falErrData = await falRes.json().catch(() => ({}));
          console.warn('fal.ai status no-ok:', falRes.status, falErrData);
        }
      } catch (falErr: any) {
        console.warn('Error en fal.ai generation, pasando a siguiente motor:', falErr.message);
      }
    }

    // 2. Try Hugging Face if requested or available
    const hfToken = process.env.HUGGINGFACE_API_KEY || process.env.HF_TOKEN;
    if ((provider === 'huggingface' || provider === 'auto') && hfToken) {
      try {
        const hfRes = await fetch(
          'https://router.huggingface.co/hf-inference/models/black-forest-labs/FLUX.1-schnell',
          {
            method: 'POST',
            headers: {
              Authorization: `Bearer ${hfToken}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ inputs: enhancedPrompt }),
          }
        );

        if (hfRes.ok) {
          const arrayBuffer = await hfRes.arrayBuffer();
          const base64 = Buffer.from(arrayBuffer).toString('base64');
          const mime = hfRes.headers.get('content-type') || 'image/jpeg';
          return res.json({
            imageUrl: `data:${mime};base64,${base64}`,
            prompt: enhancedPrompt,
            provider: 'Hugging Face (FLUX)',
          });
        }
      } catch (hfErr: any) {
        console.warn('Error en Hugging Face inference, pasando a siguiente motor:', hfErr.message);
      }
    }

    // 3. Try Gemini Studio Image model
    try {
      const parts: any[] = [];
      if (referenceImage) {
        const base64Data = referenceImage.replace(/^data:image\/\w+;base64,/, '');
        const mimeMatch = referenceImage.match(/^data:(image\/\w+);base64,/);
        const mimeType = mimeMatch ? mimeMatch[1] : 'image/jpeg';
        parts.push({
          inlineData: {
            mimeType,
            data: base64Data,
          },
        });
      }
      parts.push({ text: enhancedPrompt });

      const response = await ai.models.generateContent({
        model: 'gemini-3.1-flash-lite-image',
        contents: { parts },
        config: {
          imageConfig: {
            aspectRatio: aspectRatio === '9:16' || aspectRatio === '16:9' ? aspectRatio : '1:1',
          },
        },
      });

      let imageUrl: string | null = null;
      if (response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData?.data) {
            const mime = part.inlineData.mimeType || 'image/png';
            imageUrl = `data:${mime};base64,${part.inlineData.data}`;
            break;
          }
        }
      }

      if (imageUrl) {
        return res.json({ imageUrl, prompt: enhancedPrompt, provider: 'Google Gemini' });
      }
    } catch (modelErr: any) {
      console.warn('Fallo intento con modelo Gemini de imagen:', modelErr.message);
    }

    // 4. High-Performance FLUX Real Image Engine (Guaranteed Real JPEG Avatar)
    try {
      const seed = Math.floor(Math.random() * 1000000);
      const encoded = encodeURIComponent(enhancedPrompt);
      const w = aspectRatio === '9:16' ? 576 : 768;
      const h = aspectRatio === '9:16' ? 1024 : 768;
      const fluxUrl = `https://image.pollinations.ai/prompt/${encoded}?width=${w}&height=${h}&seed=${seed}&nologo=true&model=flux`;

      const pollRes = await fetch(fluxUrl, { signal: AbortSignal.timeout(12000) });
      if (pollRes.ok) {
        const buffer = await pollRes.arrayBuffer();
        const base64 = Buffer.from(buffer).toString('base64');
        return res.json({
          imageUrl: `data:image/jpeg;base64,${base64}`,
          prompt: enhancedPrompt,
          provider: 'FLUX.1 Pro Studio',
        });
      }
    } catch (fluxErr: any) {
      console.warn('Error en FLUX Pro Studio:', fluxErr.message);
    }

    // 5. Creative dynamic SVG avatar renderer fallback
    const svgAvatar = generateArtisticAvatarSvg(enhancedPrompt, style);
    const base64Svg = Buffer.from(svgAvatar).toString('base64');
    const imageUrl = `data:image/svg+xml;base64,${base64Svg}`;

    res.json({
      imageUrl,
      prompt: enhancedPrompt,
      isArtisticRender: true,
      provider: provider === 'fal' ? 'fal.ai (modo simulación)' : provider === 'huggingface' ? 'Hugging Face (modo simulación)' : 'Creado Ando Art Studio',
    });
  } catch (error: any) {
    console.error('Error en /api/generate-image:', error);
    res.status(500).json({ error: 'No se pudo generar la imagen', details: error.message });
  }
});

// Helper for creative avatar generator fallback
function generateArtisticAvatarSvg(prompt: string, style?: string): string {
  const isChibi = /chibi|cute|tierno/i.test(prompt + ' ' + (style || ''));
  const isAnime = /anime|manga/i.test(prompt + ' ' + (style || ''));
  const is3D = /3d|pixar|disney/i.test(prompt + ' ' + (style || ''));
  const isSunflower = /girasol|amarillo|sunflower/i.test(prompt);

  const bgGradient = isSunflower
    ? 'linear-gradient(135deg, #FEF08A, #F59E0B)'
    : is3D
    ? 'linear-gradient(135deg, #60A5FA, #3B82F6)'
    : isAnime
    ? 'linear-gradient(135deg, #F472B6, #9333EA)'
    : 'linear-gradient(135deg, #FDE047, #EAB308)';

  return `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="100%" height="100%">
    <defs>
      <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#FFFBEB" />
        <stop offset="100%" stop-color="#FEF08A" />
      </linearGradient>
      <linearGradient id="skin" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stop-color="#FFE4C7" />
        <stop offset="100%" stop-color="#FCD3A1" />
      </linearGradient>
      <linearGradient id="hair" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#92400E" />
        <stop offset="100%" stop-color="#451A03" />
      </linearGradient>
      <linearGradient id="gold" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#FBBF24" />
        <stop offset="100%" stop-color="#D97706" />
      </linearGradient>
      <filter id="shadow" x="-10%" y="-10%" width="120%" height="120%">
        <feDropShadow dx="0" dy="8" stdDeviation="12" flood-color="#78350F" flood-opacity="0.15" />
      </filter>
    </defs>

    <!-- Background -->
    <rect width="512" height="512" fill="url(#bg)" rx="48"/>

    <!-- Decorative Sunflowers background -->
    <g opacity="0.25">
      <circle cx="80" cy="80" r="40" fill="#F59E0B" />
      <circle cx="80" cy="80" r="18" fill="#78350F" />
      <circle cx="430" cy="110" r="50" fill="#EAB308" />
      <circle cx="430" cy="110" r="22" fill="#78350F" />
      <circle cx="70" cy="440" r="45" fill="#FBBF24" />
      <circle cx="70" cy="440" r="20" fill="#78350F" />
    </g>

    <!-- Character Body / Outfit -->
    <g filter="url(#shadow)">
      <path d="M156 360 C156 300, 356 300, 356 360 L380 512 L132 512 Z" fill="#F59E0B" />
      <!-- Collar / Jacket detail -->
      <path d="M216 320 L256 370 L296 320 L256 420 Z" fill="#FEF3C7" />
      <circle cx="256" cy="385" r="8" fill="#78350F" />
      <circle cx="256" cy="425" r="8" fill="#78350F" />
      
      <!-- Neck -->
      <rect x="236" y="270" width="40" height="60" rx="10" fill="url(#skin)" />

      <!-- Head & Ears -->
      <circle cx="180" cy="220" r="20" fill="url(#skin)" />
      <circle cx="332" cy="220" r="20" fill="url(#skin)" />
      <ellipse cx="256" cy="210" rx="${isChibi ? '90' : '80'}" ry="${isChibi ? '85' : '95'}" fill="url(#skin)" />

      <!-- Eyes -->
      <ellipse cx="215" cy="205" rx="${isAnime ? '18' : '14'}" ry="${isAnime ? '24' : '18'}" fill="#3B250E" />
      <ellipse cx="297" cy="205" rx="${isAnime ? '18' : '14'}" ry="${isAnime ? '24' : '18'}" fill="#3B250E" />
      <!-- Eye Sparkles -->
      <circle cx="210" cy="198" r="6" fill="#FFFFFF" />
      <circle cx="220" cy="214" r="3" fill="#FFFFFF" />
      <circle cx="292" cy="198" r="6" fill="#FFFFFF" />
      <circle cx="302" cy="214" r="3" fill="#FFFFFF" />

      <!-- Cute Cheeks -->
      <ellipse cx="195" cy="235" rx="15" ry="8" fill="#FB7185" opacity="0.6" />
      <ellipse cx="317" cy="235" rx="15" ry="8" fill="#FB7185" opacity="0.6" />

      <!-- Smile -->
      <path d="M236 245 Q256 265 276 245" stroke="#9A3412" stroke-width="4" stroke-linecap="round" fill="none" />

      <!-- Hair -->
      <path d="M165 190 C150 110, 362 110, 347 190 C330 130, 180 130, 165 190 Z" fill="url(#hair)" />
      <path d="M176 160 Q256 120 336 160 Q256 140 176 160" fill="url(#gold)" />
      <path d="M220 130 Q256 180 290 130 Q256 150 220 130" fill="url(#hair)" />

      <!-- Sunflower Hair Accessory -->
      <g transform="translate(320, 130) scale(0.6)">
        <circle cx="40" cy="40" r="35" fill="#EAB308" />
        <circle cx="40" cy="40" r="18" fill="#78350F" />
        <circle cx="40" cy="40" r="14" fill="#451A03" />
      </g>
    </g>

    <!-- Studio Watermark badge -->
    <rect x="24" y="24" width="150" height="34" rx="17" fill="#FEF3C7" opacity="0.9" />
    <text x="99" y="46" font-family="system-ui, sans-serif" font-size="13" font-weight="700" fill="#92400E" text-anchor="middle">🌻 Creado Ando</text>
  </svg>
  `.trim();
}

// Photo analysis endpoint
app.post('/api/analyze-photo', async (req: Request, res: Response) => {
  try {
    const { imageBase64 } = req.body;
    if (!imageBase64) {
      return res.status(400).json({ error: 'Se requiere la imagen en base64' });
    }

    const cleanBase64 = imageBase64.replace(/^data:image\/\w+;base64,/, '');
    const mimeMatch = imageBase64.match(/^data:(image\/\w+);base64,/);
    const mimeType = mimeMatch ? mimeMatch[1] : 'image/jpeg';

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType,
              data: cleanBase64,
            },
          },
          {
            text: `Analiza esta fotografía para convertirla en un "Avatar Maestro" digital para el estudio Creado Ando.
Identifica y extrae en formato breve y estructurado en español:
1. Rasgos faciales clave (forma de rostro, ojos, cejas, sonrisa).
2. Cabello (color, textura, largo, peinado).
3. Accesorios o vestuario visible.
4. 3 propuestas de estilos de avatar que mejor se adaptarían (por ejemplo: 3D Pixar, Anime estilizado, Chibi tierno o Caricatura profesional).
5. Sugerencia de prompt en inglés optimizado para generar el Avatar Maestro con consistencia.`,
          },
        ],
      },
    });

    res.json({ analysis: response.text });
  } catch (error: any) {
    console.error('Error en /api/analyze-photo:', error);
    res.status(500).json({ error: 'No se pudo analizar la foto', details: error.message });
  }
});

// Setup Vite or static serving
async function setupServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`🌻 Creado Ando server corriendo en http://localhost:${PORT}`);
  });
}

setupServer();
