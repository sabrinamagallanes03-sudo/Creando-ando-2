import React, { useState, useEffect } from 'react';
import {
  Chat,
  NovedadItem,
  MasterAvatar,
  UserProfile,
  AppSettings,
  ChatMessage,
} from './types';
import { storage } from './lib/storage';
import { SunflowerHeader } from './components/SunflowerAssets';
import { ChatView } from './components/ChatView';
import { NovedadesView } from './components/NovedadesView';
import { AvataresView } from './components/AvataresView';
import { CameraModal } from './components/CameraModal';
import { NewChatModal } from './components/NewChatModal';
import { ContactEditModal } from './components/ContactEditModal';
import { ProfileModal } from './components/ProfileModal';
import { SettingsModal } from './components/SettingsModal';
import { SunflowerCustomizerModal } from './components/SunflowerCustomizerModal';
import {
  Camera,
  Search,
  MoreVertical,
  MessageSquarePlus,
  Pin,
  CheckCheck,
  User,
  Settings,
  Tv,
  Crown,
  Share2,
  X,
  Palette,
  Trash2,
} from 'lucide-react';

export default function App() {
  // State loaded strictly from localStorage (Clean / Empty on first launch)
  const [chats, setChats] = useState<Chat[]>(() => storage.getChats());
  const [novedades, setNovedades] = useState<NovedadItem[]>(() => storage.getNovedades());
  const [avatares, setAvatares] = useState<MasterAvatar[]>(() => storage.getAvatares());
  const [profile, setProfile] = useState<UserProfile>(() => storage.getProfile());
  const [settings, setSettings] = useState<AppSettings>(() => storage.getSettings());

  // Active view states
  const [activeTab, setActiveTab] = useState<'chats' | 'novedades' | 'avatares'>('chats');
  const [activeChatId, setActiveChatId] = useState<string | null>(null);

  // Search & Filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  // Modals state
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [isNewChatOpen, setIsNewChatOpen] = useState(false);
  const [editingChat, setEditingChat] = useState<Chat | null>(null);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isSunflowerCustomizerOpen, setIsSunflowerCustomizerOpen] = useState(false);
  const [isTopMenuOpen, setIsTopMenuOpen] = useState(false);

  // Save changes to storage
  useEffect(() => {
    storage.saveChats(chats);
  }, [chats]);

  useEffect(() => {
    storage.saveNovedades(novedades);
  }, [novedades]);

  useEffect(() => {
    storage.saveAvatares(avatares);
  }, [avatares]);

  // Handlers for Chats
  const handleStartNewDirectChat = () => {
    const chatNum = chats.length + 1;
    const newChat = storage.createChat(
      `Conversación ${chatNum}`,
      'en línea 🌻',
      undefined
    );
    const welcomeMsg: ChatMessage = {
      id: 'msg_welcome_' + Date.now(),
      role: 'assistant',
      content: '¡Hola Sabrina! ¿Cómo estás hoy? Cuéntame qué tienes en mente o qué te gustaría que diseñemos juntos 🌻',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    newChat.messages = [welcomeMsg];
    storage.updateChat(newChat.id, { messages: [welcomeMsg] });
    setChats(storage.getChats());
    setActiveChatId(newChat.id);
  };

  const handleCreateChat = (title: string, status?: string, avatarUrl?: string, initialPrompt?: string) => {
    const newChat = storage.createChat(title, status, avatarUrl);
    if (initialPrompt) {
      const initMessage: ChatMessage = {
        id: 'msg_init_' + Date.now(),
        role: 'user',
        content: initialPrompt,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      newChat.messages = [initMessage];
      storage.updateChat(newChat.id, { messages: [initMessage] });
    }
    setChats(storage.getChats());
    setActiveChatId(newChat.id);
  };

  const handleUpdateChat = (chatId: string, updates: Partial<Chat>) => {
    const updated = storage.updateChat(chatId, updates);
    setChats(updated);
  };

  const handleDeleteChat = (chatId: string) => {
    const updated = storage.deleteChat(chatId);
    setChats(updated);
    if (activeChatId === chatId) {
      setActiveChatId(null);
    }
  };

  const handleClearMessages = (chatId: string) => {
    const updated = storage.clearMessages(chatId);
    setChats(updated);
  };

  const handleSendMessage = (chatId: string, message: ChatMessage) => {
    const updated = storage.addMessage(chatId, message);
    setChats(updated);
  };

  // Handlers for Novedades
  const handleAddNovedad = (item: Omit<NovedadItem, 'id' | 'createdAt' | 'likes'>) => {
    const newItem = storage.addNovedad(item);
    setNovedades(storage.getNovedades());
    return newItem;
  };

  const handleDeleteNovedad = (id: string) => {
    const updated = storage.deleteNovedad(id);
    setNovedades(updated);
  };

  const handleLikeNovedad = (id: string) => {
    const updated = storage.likeNovedad(id);
    setNovedades(updated);
  };

  // Handlers for Avatares
  const handleAddAvatar = (avatar: Omit<MasterAvatar, 'id' | 'createdAt'>) => {
    const newAvatar = storage.addAvatar(avatar);
    setAvatares(storage.getAvatares());
    return newAvatar;
  };

  const handleDeleteAvatar = (id: string) => {
    const updated = storage.deleteAvatar(id);
    setAvatares(updated);
  };

  const handleOpenChatWithAvatar = (avatar: MasterAvatar) => {
    const chatTitle = `Avatar: ${avatar.name}`;
    let existingChat = chats.find((c) => c.title === chatTitle);
    if (!existingChat) {
      existingChat = storage.createChat(chatTitle, `Estilo: ${avatar.style}`, avatar.imageUrl);
      setChats(storage.getChats());
    }
    setActiveChatId(existingChat.id);
    setActiveTab('chats');
  };

  // Handlers for Profile & Settings
  const handleSaveProfile = (newProfile: UserProfile) => {
    storage.saveProfile(newProfile);
    setProfile(newProfile);
  };

  const handleSaveSettings = (newSettings: AppSettings) => {
    storage.saveSettings(newSettings);
    setSettings(newSettings);
  };

  const handleExportData = () => {
    const dataStr = storage.exportAllData();
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `creado-ando-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportData = (jsonStr: string) => {
    const success = storage.importAllData(jsonStr);
    if (success) {
      setChats(storage.getChats());
      setNovedades(storage.getNovedades());
      setAvatares(storage.getAvatares());
      setProfile(storage.getProfile());
      setSettings(storage.getSettings());
    }
    return success;
  };

  const handleClearAllData = () => {
    storage.clearAllData();
    setChats([]);
    setNovedades([]);
    setAvatares([]);
    setProfile(storage.getProfile());
    setSettings(storage.getSettings());
    setActiveChatId(null);
  };

  // Camera capture handler
  const handlePhotoCaptured = (base64Photo: string) => {
    if (activeChatId) {
      // Send directly in active chat
      const photoMessage: ChatMessage = {
        id: 'msg_cam_' + Date.now(),
        role: 'user',
        content: 'Te comparto esta foto para crear mi Avatar Maestro o nuevo contenido 🌻',
        image: base64Photo,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      handleSendMessage(activeChatId, photoMessage);
    } else {
      // Create new chat with this photo
      const newChat = storage.createChat('Nuevo Proyecto Avatar', 'Foto capturada 🌻', base64Photo);
      const initMessage: ChatMessage = {
        id: 'msg_cam_' + Date.now(),
        role: 'user',
        content: '¡Hola! Quiero usar esta foto para crear mi Avatar Maestro. Analiza mis rasgos físicos y propón estilos.',
        image: base64Photo,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      newChat.messages = [initMessage];
      storage.updateChat(newChat.id, { messages: [initMessage] });
      setChats(storage.getChats());
      setActiveChatId(newChat.id);
    }
  };

  // Filtered chats
  const filteredChats = chats
    .filter((c) => {
      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase();
      const inTitle = c.title.toLowerCase().includes(q);
      const inStatus = c.status.toLowerCase().includes(q);
      const inMessages = c.messages.some((m) => m.content.toLowerCase().includes(q));
      return inTitle || inStatus || inMessages;
    })
    .sort((a, b) => {
      if (a.isPinned && !b.isPinned) return -1;
      if (!a.isPinned && b.isPinned) return 1;
      return b.updatedAt - a.updatedAt;
    });

  const activeChat = chats.find((c) => c.id === activeChatId) || null;

  return (
    <div className="flex justify-center bg-stone-900 min-h-screen text-stone-900 font-sans selection:bg-amber-200 selection:text-amber-900">
      {/* Mobile-First Frame: Exactly sized like a phone screen or responsive container */}
      <div className="w-full max-w-md bg-white min-h-screen flex flex-col shadow-2xl relative overflow-hidden">
        {/* If Active Chat is selected, show ChatView */}
        {activeChat ? (
          <ChatView
            chat={activeChat}
            settings={settings}
            onBack={() => setActiveChatId(null)}
            onSendMessage={handleSendMessage}
            onOpenEditContact={() => setEditingChat(activeChat)}
            onSaveAsAvatar={(avatar) => handleAddAvatar(avatar)}
            onPublishToNovedades={(title, desc, media, cat) =>
              handleAddNovedad({
                title,
                description: desc,
                mediaUrl: media,
                mediaType: 'image',
                category: cat,
              })
            }
            onOpenLiveCamera={() => setIsCameraOpen(true)}
            onDeleteChat={handleDeleteChat}
            onClearMessages={handleClearMessages}
            onOpenSettings={() => setIsSettingsOpen(true)}
            onOpenSunflowerCustomizer={() => setIsSunflowerCustomizerOpen(true)}
            onOpenNovedades={() => {
              setActiveChatId(null);
              setActiveTab('novedades');
            }}
          />
        ) : (
          /* Main WhatsApp Interface (Sunflower Header + Tabs) */
          <>
            {/* Top Sunflower Design Header */}
            <SunflowerHeader
              style={settings.headerStyle}
              customImageUrl={settings.customHeaderImageUrl}
              customConfig={settings.sunflowerConfig}
            >
              {/* Header Title & Icons Row */}
              <div className="px-4 pt-3.5 pb-2 flex items-center justify-between">
                {/* Title requested by user: "Donde dice avatar universe que diga creado ando." */}
                <div className="flex items-center gap-2">
                  <h1 className="font-extrabold text-xl tracking-tight text-white drop-shadow-sm font-sans">
                    Creado Ando
                  </h1>
                  <span className="text-xs bg-amber-400/90 text-stone-950 font-bold px-2 py-0.5 rounded-full shadow-xs">
                    Estudio
                  </span>
                </div>

                {/* Right Top Icons (Sunflower, Settings, Camera, Search, 3-Dots Menu) */}
                <div className="flex items-center gap-1 text-white">
                  {/* Direct button to Sunflower Designer */}
                  <button
                    onClick={() => setIsSunflowerCustomizerOpen(true)}
                    className="p-2 rounded-full hover:bg-white/20 active:scale-95 transition"
                    title="Diseñar mis girasoles a mi gusto"
                  >
                    <span className="text-base leading-none">🌻</span>
                  </button>

                  {/* Direct button to Settings */}
                  <button
                    onClick={() => setIsSettingsOpen(true)}
                    className="p-2 rounded-full hover:bg-white/20 active:scale-95 transition"
                    title="Ajustes de la aplicación"
                  >
                    <Settings className="w-5 h-5" />
                  </button>

                  <button
                    onClick={() => setIsCameraOpen(true)}
                    className="p-2 rounded-full hover:bg-white/20 active:scale-95 transition"
                    title="Cámara"
                  >
                    <Camera className="w-5 h-5" />
                  </button>

                  <button
                    onClick={() => setIsSearchOpen(!isSearchOpen)}
                    className="p-2 rounded-full hover:bg-white/20 active:scale-95 transition"
                    title="Buscar"
                  >
                    <Search className="w-5 h-5" />
                  </button>

                  <div className="relative">
                    <button
                      onClick={() => setIsTopMenuOpen(!isTopMenuOpen)}
                      className="p-2 rounded-full hover:bg-white/20 active:scale-95 transition"
                      title="Más opciones"
                    >
                      <MoreVertical className="w-5 h-5" />
                    </button>

                    {/* WhatsApp 3-Dots Dropdown Menu */}
                    {isTopMenuOpen && (
                      <>
                        <div
                          className="fixed inset-0 z-30"
                          onClick={() => setIsTopMenuOpen(false)}
                        />
                        <div className="absolute right-0 top-11 w-56 bg-white rounded-2xl shadow-2xl py-2 z-40 text-stone-800 border border-stone-200 animate-in fade-in zoom-in-95 duration-150">
                          <button
                            onClick={() => {
                              setIsTopMenuOpen(false);
                              handleStartNewDirectChat();
                            }}
                            className="w-full text-left px-4 py-2.5 hover:bg-amber-50 text-xs font-semibold flex items-center gap-2.5 text-stone-800"
                          >
                            <MessageSquarePlus className="w-4 h-4 text-amber-600" />
                            Nuevo chat directo
                          </button>

                          <button
                            onClick={() => {
                              setIsTopMenuOpen(false);
                              setActiveTab('novedades');
                            }}
                            className="w-full text-left px-4 py-2.5 hover:bg-amber-50 text-xs font-semibold flex items-center gap-2.5 text-stone-800"
                          >
                            <Tv className="w-4 h-4 text-amber-600" />
                            Publicar en Novedades
                          </button>

                          <button
                            onClick={() => {
                              setIsTopMenuOpen(false);
                              setActiveTab('avatares');
                            }}
                            className="w-full text-left px-4 py-2.5 hover:bg-amber-50 text-xs font-semibold flex items-center gap-2.5 text-stone-800"
                          >
                            <Crown className="w-4 h-4 text-amber-600" />
                            Avatares Maestros
                          </button>

                          <div className="h-px bg-stone-100 my-1" />

                          <button
                            onClick={() => {
                              setIsTopMenuOpen(false);
                              setIsSunflowerCustomizerOpen(true);
                            }}
                            className="w-full text-left px-4 py-2.5 hover:bg-amber-50 text-xs font-semibold flex items-center gap-2.5 text-stone-800"
                          >
                            <span className="text-base">🌻</span>
                            Diseñar mis girasoles a mi gusto
                          </button>

                          <button
                            onClick={() => {
                              setIsTopMenuOpen(false);
                              setIsSettingsOpen(true);
                            }}
                            className="w-full text-left px-4 py-2.5 hover:bg-amber-50 text-xs font-semibold flex items-center gap-2.5 text-stone-800"
                          >
                            <Palette className="w-4 h-4 text-amber-600" />
                            Personalizar diseño con imagen 🎨
                          </button>

                          <button
                            onClick={() => {
                              setIsTopMenuOpen(false);
                              setIsProfileOpen(true);
                            }}
                            className="w-full text-left px-4 py-2.5 hover:bg-amber-50 text-xs font-semibold flex items-center gap-2.5 text-stone-800"
                          >
                            <User className="w-4 h-4 text-amber-600" />
                            Perfil de diseñadora
                          </button>

                          <button
                            onClick={() => {
                              setIsTopMenuOpen(false);
                              setIsSettingsOpen(true);
                            }}
                            className="w-full text-left px-4 py-2.5 hover:bg-amber-50 text-xs font-semibold flex items-center gap-2.5 text-stone-800"
                          >
                            <Settings className="w-4 h-4 text-amber-600" />
                            Ajustes y Temas 🌻
                          </button>
                        </div>
                      </>
                    )}
                  </div>
                </div>
              </div>

              {/* Quick Search Input */}
              {isSearchOpen && (
                <div className="px-4 pb-2.5 animate-in slide-in-from-top-2 duration-150">
                  <div className="relative">
                    <input
                      type="text"
                      autoFocus
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Buscar chats, contactos o mensajes..."
                      className="w-full pl-9 pr-8 py-2 rounded-xl bg-white/95 text-stone-900 placeholder-stone-400 text-xs focus:outline-none shadow-inner"
                    />
                    <Search className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
                    {searchQuery && (
                      <button
                        onClick={() => setSearchQuery('')}
                        className="absolute right-2.5 top-2.5 text-stone-400 hover:text-stone-700"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              )}

              {/* WhatsApp Tabs Bar: [Camera icon, CHATS, ACTUALIZACIONES, AVATARES, AJUSTES] */}
              <div className="flex items-center text-white/90 text-xs font-bold uppercase tracking-wider px-2">
                <button
                  onClick={() => setIsCameraOpen(true)}
                  className="p-3 hover:text-white transition active:scale-95"
                  title="Abrir cámara"
                >
                  <Camera className="w-4 h-4" />
                </button>

                {/* Chats Tab */}
                <button
                  onClick={() => setActiveTab('chats')}
                  className={`flex-1 py-3 text-center transition relative flex items-center justify-center gap-1.5 ${
                    activeTab === 'chats' ? 'text-white font-extrabold' : 'text-white/70 hover:text-white'
                  }`}
                >
                  <span>Chats</span>
                  {chats.length > 0 && (
                    <span className="w-4 h-4 rounded-full bg-white text-amber-800 text-[10px] font-bold flex items-center justify-center">
                      {chats.length}
                    </span>
                  )}
                  {activeTab === 'chats' && (
                    <div className="absolute bottom-0 left-0 right-0 h-1 bg-white rounded-t-full shadow-xs" />
                  )}
                </button>

                {/* Actualizaciones (Novedades) Tab */}
                <button
                  onClick={() => setActiveTab('novedades')}
                  className={`flex-1 py-3 text-center transition relative flex items-center justify-center gap-1.5 ${
                    activeTab === 'novedades'
                      ? 'text-white font-extrabold'
                      : 'text-white/70 hover:text-white'
                  }`}
                  title="Actualizaciones y Novedades"
                >
                  <span>Actualizaciones</span>
                  {novedades.length > 0 && (
                    <span className="w-2 h-2 rounded-full bg-amber-300" />
                  )}
                  {activeTab === 'novedades' && (
                    <div className="absolute bottom-0 left-0 right-0 h-1 bg-white rounded-t-full shadow-xs" />
                  )}
                </button>

                {/* Avatares Tab */}
                <button
                  onClick={() => setActiveTab('avatares')}
                  className={`flex-1 py-3 text-center transition relative flex items-center justify-center gap-1.5 ${
                    activeTab === 'avatares'
                      ? 'text-white font-extrabold'
                      : 'text-white/70 hover:text-white'
                  }`}
                >
                  <span>Avatares</span>
                  {avatares.length > 0 && (
                    <span className="w-4 h-4 rounded-full bg-amber-300/80 text-stone-950 text-[10px] font-bold flex items-center justify-center">
                      {avatares.length}
                    </span>
                  )}
                  {activeTab === 'avatares' && (
                    <div className="absolute bottom-0 left-0 right-0 h-1 bg-white rounded-t-full shadow-xs" />
                  )}
                </button>

                {/* Ajustes Tab */}
                <button
                  onClick={() => setIsSettingsOpen(true)}
                  className="flex-1 py-3 text-center transition relative flex items-center justify-center gap-1 text-white/80 hover:text-white"
                  title="Abrir Ajustes"
                >
                  <Settings className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Ajustes</span>
                </button>
              </div>
            </SunflowerHeader>

            {/* Tab Contents */}
            <div className="flex-1 flex flex-col overflow-hidden relative">
              {activeTab === 'chats' && (
                <div className="flex-1 overflow-y-auto pb-24 divide-y divide-stone-100 bg-white">
                  {filteredChats.length === 0 ? (
                    /* Strictly Empty Initial State (No generic mock contacts or fake images) */
                    <div className="py-20 px-6 text-center flex flex-col items-center justify-center">
                      <div className="w-24 h-24 rounded-full bg-amber-50 border-2 border-dashed border-amber-300 flex items-center justify-center text-4xl mb-4 shadow-inner">
                        🌻
                      </div>
                      <h3 className="font-extrabold text-stone-900 text-lg mb-2">
                        Bienvenida a Creado Ando
                      </h3>
                      <p className="text-xs text-stone-500 max-w-xs leading-relaxed mb-6">
                        No hay conversaciones ni contenido precreado. Aquí todo se crea a través del chat:
                        avatares maestros con fotos de tu galería o cámara, vestuarios, historietas,
                        miniseries, stickers y publicidad para vender.
                      </p>
                      <button
                        onClick={handleStartNewDirectChat}
                        className="px-6 py-3 rounded-full bg-gradient-to-r from-amber-500 to-yellow-400 text-stone-950 font-bold text-xs hover:from-amber-400 hover:to-yellow-300 active:scale-95 transition shadow-lg shadow-amber-500/25 flex items-center gap-2"
                      >
                        <MessageSquarePlus className="w-4 h-4 stroke-[2.5]" />
                        Iniciar primer chat o proyecto
                      </button>
                    </div>
                  ) : (
                    /* Chat list items like WhatsApp */
                    filteredChats.map((chat) => {
                      const lastMessage = chat.messages[chat.messages.length - 1];
                      const formattedTime = lastMessage
                        ? lastMessage.timestamp
                        : new Date(chat.updatedAt).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit',
                          });

                      return (
                        <div
                          key={chat.id}
                          onClick={() => setActiveChatId(chat.id)}
                          className="px-4 py-3 flex items-center gap-3.5 hover:bg-stone-50 active:bg-amber-50/50 cursor-pointer transition select-none group"
                        >
                          {/* Contact Avatar Circle */}
                          <div
                            onClick={(e) => {
                              e.stopPropagation();
                              setEditingChat(chat);
                            }}
                            className="w-13 h-13 rounded-full overflow-hidden bg-amber-100 border border-amber-300 flex items-center justify-center text-amber-900 font-bold text-base shrink-0 shadow-xs group-hover:scale-105 transition"
                            title="Toca para editar contacto"
                          >
                            {chat.avatarUrl ? (
                              <img
                                src={chat.avatarUrl}
                                alt={chat.title}
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              <span>{chat.title.charAt(0).toUpperCase() || '🌻'}</span>
                            )}
                          </div>

                          {/* Chat Title & Last Message */}
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between mb-0.5">
                              <h4 className="font-bold text-sm text-stone-900 truncate">
                                {chat.title}
                              </h4>
                              <span className="text-[11px] text-stone-400 shrink-0 font-medium">
                                {formattedTime}
                              </span>
                            </div>

                            <div className="flex items-center justify-between">
                              <p className="text-xs text-stone-500 truncate flex items-center gap-1 flex-1 min-w-0 pr-2">
                                {lastMessage ? (
                                  <>
                                    {lastMessage.role === 'user' && (
                                      <CheckCheck className="w-3.5 h-3.5 text-sky-600 shrink-0" />
                                    )}
                                    <span className="truncate">
                                      {lastMessage.content || '📷 Foto enviada'}
                                    </span>
                                  </>
                                ) : (
                                  <span className="italic text-stone-400">{chat.status}</span>
                                )}
                              </p>

                              <div className="flex items-center gap-1 shrink-0">
                                {chat.isPinned && (
                                  <Pin className="w-3.5 h-3.5 text-amber-600 mr-1" />
                                )}

                                {/* Quick delete chat button when done with client */}
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    if (
                                      window.confirm(
                                        `¿Deseas eliminar la conversación con "${chat.title}"? Una vez borrada no se podrá recuperar.`
                                      )
                                    ) {
                                      handleDeleteChat(chat.id);
                                    }
                                  }}
                                  className="p-1.5 rounded-full text-stone-400 hover:text-red-600 hover:bg-red-50 transition active:scale-90"
                                  title="Eliminar conversación de este cliente"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              )}

              {/* Novedades Tab View */}
              {activeTab === 'novedades' && (
                <NovedadesView
                  items={novedades}
                  profile={profile}
                  onAddItem={handleAddNovedad}
                  onDeleteItem={handleDeleteNovedad}
                  onLikeItem={handleLikeNovedad}
                  onOpenLiveCamera={() => setIsCameraOpen(true)}
                />
              )}

              {/* Avatares Tab View */}
              {activeTab === 'avatares' && (
                <AvataresView
                  avatares={avatares}
                  onAddAvatar={handleAddAvatar}
                  onDeleteAvatar={handleDeleteAvatar}
                  onOpenChatWithAvatar={handleOpenChatWithAvatar}
                  onOpenLiveCamera={() => setIsCameraOpen(true)}
                />
              )}

              {/* WhatsApp Floating Action Button (FAB) */}
              {activeTab === 'chats' && (
                <button
                  onClick={handleStartNewDirectChat}
                  className="absolute bottom-6 right-5 w-14 h-14 rounded-full bg-gradient-to-r from-amber-500 to-yellow-400 text-stone-950 flex items-center justify-center shadow-xl shadow-amber-500/30 hover:scale-105 active:scale-95 transition z-30"
                  title="Nuevo chat directo"
                  aria-label="Nuevo chat"
                >
                  <MessageSquarePlus className="w-6 h-6 stroke-[2.5]" />
                </button>
              )}
            </div>

            {/* WhatsApp Authentic Bottom Navigation Bar */}
            <nav className="bg-white border-t border-stone-200 px-2 py-1 flex items-center justify-around z-20 shrink-0 text-stone-600 shadow-lg">
              {/* Chats */}
              <button
                type="button"
                onClick={() => setActiveTab('chats')}
                className={`flex flex-col items-center gap-0.5 py-1 px-3 rounded-xl transition ${
                  activeTab === 'chats'
                    ? 'text-amber-600 font-extrabold'
                    : 'text-stone-500 hover:text-stone-800'
                }`}
              >
                <div className="relative">
                  <MessageSquarePlus className="w-5 h-5" />
                  {chats.length > 0 && (
                    <span className="absolute -top-1 -right-2 bg-amber-500 text-stone-950 text-[9px] font-bold rounded-full w-3.5 h-3.5 flex items-center justify-center">
                      {chats.length}
                    </span>
                  )}
                </div>
                <span className="text-[10px]">Chats</span>
              </button>

              {/* Actualizaciones */}
              <button
                type="button"
                onClick={() => setActiveTab('novedades')}
                className={`flex flex-col items-center gap-0.5 py-1 px-3 rounded-xl transition ${
                  activeTab === 'novedades'
                    ? 'text-amber-600 font-extrabold'
                    : 'text-stone-500 hover:text-stone-800'
                }`}
              >
                <div className="relative">
                  <Tv className="w-5 h-5" />
                  {novedades.length > 0 && (
                    <span className="absolute -top-0.5 -right-0.5 bg-amber-500 rounded-full w-2 h-2" />
                  )}
                </div>
                <span className="text-[10px]">Actualizaciones</span>
              </button>

              {/* Avatares */}
              <button
                type="button"
                onClick={() => setActiveTab('avatares')}
                className={`flex flex-col items-center gap-0.5 py-1 px-3 rounded-xl transition ${
                  activeTab === 'avatares'
                    ? 'text-amber-600 font-extrabold'
                    : 'text-stone-500 hover:text-stone-800'
                }`}
              >
                <Crown className="w-5 h-5" />
                <span className="text-[10px]">Avatares</span>
              </button>

              {/* Personalizar Girasoles */}
              <button
                type="button"
                onClick={() => setIsSunflowerCustomizerOpen(true)}
                className="flex flex-col items-center gap-0.5 py-1 px-3 rounded-xl text-stone-500 hover:text-amber-600 transition"
                title="Diseñar girasoles"
              >
                <span className="text-lg leading-none">🌻</span>
                <span className="text-[10px]">Personalizar</span>
              </button>

              {/* Ajustes */}
              <button
                type="button"
                onClick={() => setIsSettingsOpen(true)}
                className="flex flex-col items-center gap-0.5 py-1 px-3 rounded-xl text-stone-500 hover:text-amber-600 transition"
                title="Ajustes generales"
              >
                <Settings className="w-5 h-5" />
                <span className="text-[10px]">Ajustes</span>
              </button>
            </nav>
          </>
        )}

        {/* Modals */}
        <CameraModal
          isOpen={isCameraOpen}
          onClose={() => setIsCameraOpen(false)}
          onPhotoCaptured={handlePhotoCaptured}
          title="Cámara de Creado Ando"
        />

        <SunflowerCustomizerModal
          isOpen={isSunflowerCustomizerOpen}
          onClose={() => setIsSunflowerCustomizerOpen(false)}
          currentConfig={settings.sunflowerConfig}
          onSave={(cfg, st) => {
            const updated = {
              ...settings,
              headerStyle: st,
              sunflowerConfig: cfg,
            };
            handleSaveSettings(updated);
          }}
          onOpenLiveCamera={() => {
            setIsSunflowerCustomizerOpen(false);
            setIsCameraOpen(true);
          }}
        />

        <NewChatModal
          isOpen={isNewChatOpen}
          onClose={() => setIsNewChatOpen(false)}
          onCreate={handleCreateChat}
          onOpenLiveCamera={() => {
            setIsNewChatOpen(false);
            setIsCameraOpen(true);
          }}
        />

        <ContactEditModal
          chat={editingChat}
          isOpen={Boolean(editingChat)}
          onClose={() => setEditingChat(null)}
          onSave={handleUpdateChat}
          onDelete={handleDeleteChat}
          onClearMessages={handleClearMessages}
          onOpenLiveCamera={() => {
            setEditingChat(null);
            setIsCameraOpen(true);
          }}
        />

        <ProfileModal
          isOpen={isProfileOpen}
          onClose={() => setIsProfileOpen(false)}
          profile={profile}
          onSave={handleSaveProfile}
          onOpenLiveCamera={() => {
            setIsProfileOpen(false);
            setIsCameraOpen(true);
          }}
        />

        <SettingsModal
          isOpen={isSettingsOpen}
          onClose={() => setIsSettingsOpen(false)}
          settings={settings}
          profile={profile}
          onSaveSettings={handleSaveSettings}
          onOpenProfile={() => setIsProfileOpen(true)}
          onExportData={handleExportData}
          onImportData={handleImportData}
          onClearData={handleClearAllData}
        />
      </div>
    </div>
  );
}
