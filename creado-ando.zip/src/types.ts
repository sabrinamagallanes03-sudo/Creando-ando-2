export type CreativeCategory =
  | 'maestro'
  | 'vestuario'
  | 'escenarios'
  | 'historieta'
  | 'video'
  | 'stickers'
  | 'publicidad'
  | 'general';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  image?: string;
  prompt?: string;
  isGeneratedAvatar?: boolean;
  category?: CreativeCategory;
  metadata?: {
    style?: string;
    panels?: { scene: string; dialogue: string }[];
    videoScript?: { sceneNumber: number; visual: string; audio: string; duration: string }[];
    stickerEmotion?: string;
    adTarget?: string;
  };
}

export interface Chat {
  id: string;
  title: string;
  status: string;
  avatarUrl?: string;
  updatedAt: number;
  isPinned?: boolean;
  unreadCount?: number;
  messages: ChatMessage[];
}

export interface NovedadItem {
  id: string;
  title: string;
  description: string;
  mediaUrl: string;
  mediaType: 'image' | 'video';
  category: string;
  createdAt: number;
  likes: number;
  priceOrClient?: string;
}

export interface MasterAvatar {
  id: string;
  name: string;
  imageUrl: string;
  style: string;
  features: string;
  notes?: string;
  createdAt: number;
}

export interface UserProfile {
  name: string;
  status: string;
  avatarUrl?: string;
  socialNetwork: string;
  phone: string;
}

export type HeaderSunflowerStyle =
  | 'girasoles-dorados'
  | 'girasoles-acuarela'
  | 'girasoles-botanico'
  | 'girasoles-vintage'
  | 'girasoles-noche'
  | 'imagen-personalizada'
  | 'girasoles-personalizados';

export type AIEngineProvider = 'auto' | 'gemini' | 'huggingface' | 'fal';

export interface CustomSunflowerConfig {
  petalColor: string;
  centerColor: string;
  bgGradientStart: string;
  bgGradientEnd: string;
  flowerSize: 'pequeno' | 'mediano' | 'grande';
  density: 'sutil' | 'medio' | 'abundante';
  flowerStyle: 'acuarela' | 'realista' | 'minimalista' | 'radiante' | 'boho';
  showLeaves: boolean;
  opacity: number;
}

export interface AppSettings {
  headerStyle: HeaderSunflowerStyle;
  chatWallpaperOpacity: number; // 0.05 to 0.4
  chatWallpaperBg: string; // hex
  fontSize: 'sm' | 'base' | 'lg';
  themeMode: 'sunflower-clean' | 'warm-gold' | 'light-classic';
  aiEngine: AIEngineProvider;
  customHeaderImageUrl?: string;
  customWallpaperImageUrl?: string;
  referenceDesignImage?: string;
  referenceDesignNotes?: string;
  sunflowerConfig?: CustomSunflowerConfig;
}
