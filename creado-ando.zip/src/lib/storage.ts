import { Chat, NovedadItem, MasterAvatar, UserProfile, AppSettings, ChatMessage } from '../types';

const CHATS_KEY = 'creado_ando_chats_v1';
const NOVEDADES_KEY = 'creado_ando_novedades_v1';
const AVATARES_KEY = 'creado_ando_avatares_v1';
const PROFILE_KEY = 'creado_ando_profile_v1';
const SETTINGS_KEY = 'creado_ando_settings_v1';

export const defaultSettings: AppSettings = {
  headerStyle: 'girasoles-dorados',
  chatWallpaperOpacity: 0.18,
  chatWallpaperBg: '#efeae2',
  fontSize: 'base',
  themeMode: 'sunflower-clean',
  aiEngine: 'auto',
};

export const defaultProfile: UserProfile = {
  name: 'Sabrina',
  status: 'Diseñadora de Avatares & Contenido 🌻',
  avatarUrl: '',
  socialNetwork: '@creadoando',
  phone: '',
};

export const storage = {
  // Chats (Strictly empty on first launch - no generic or mock items)
  getChats(): Chat[] {
    try {
      const data = localStorage.getItem(CHATS_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  saveChats(chats: Chat[]): void {
    try {
      localStorage.setItem(CHATS_KEY, JSON.stringify(chats));
    } catch (e) {
      console.error('Error guardando chats en localStorage', e);
    }
  },

  createChat(title: string, status = 'En línea 🌻', avatarUrl = ''): Chat {
    const chats = storage.getChats();
    const newChat: Chat = {
      id: 'chat_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      title: title.trim() || 'Nuevo Contacto',
      status: status.trim() || 'En línea 🌻',
      avatarUrl: avatarUrl || '',
      updatedAt: Date.now(),
      unreadCount: 0,
      messages: [],
    };
    storage.saveChats([newChat, ...chats]);
    return newChat;
  },

  updateChat(id: string, updates: Partial<Chat>): Chat[] {
    const chats = storage.getChats();
    const updated = chats.map((c) => (c.id === id ? { ...c, ...updates } : c));
    storage.saveChats(updated);
    return updated;
  },

  deleteChat(id: string): Chat[] {
    const chats = storage.getChats();
    const updated = chats.filter((c) => c.id !== id);
    storage.saveChats(updated);
    return updated;
  },

  addMessage(chatId: string, message: ChatMessage): Chat[] {
    const chats = storage.getChats();
    const updated = chats.map((c) => {
      if (c.id === chatId) {
        return {
          ...c,
          updatedAt: Date.now(),
          messages: [...c.messages, message],
        };
      }
      return c;
    });
    storage.saveChats(updated);
    return updated;
  },

  clearMessages(chatId: string): Chat[] {
    const chats = storage.getChats();
    const updated = chats.map((c) => (c.id === chatId ? { ...c, messages: [] } : c));
    storage.saveChats(updated);
    return updated;
  },

  // Novedades (portfolio / status showcase)
  getNovedades(): NovedadItem[] {
    try {
      const data = localStorage.getItem(NOVEDADES_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  saveNovedades(items: NovedadItem[]): void {
    try {
      localStorage.setItem(NOVEDADES_KEY, JSON.stringify(items));
    } catch (e) {
      console.error('Error guardando novedades', e);
    }
  },

  addNovedad(item: Omit<NovedadItem, 'id' | 'createdAt' | 'likes'>): NovedadItem {
    const current = storage.getNovedades();
    const newItem: NovedadItem = {
      ...item,
      id: 'nov_' + Date.now(),
      createdAt: Date.now(),
      likes: 0,
    };
    storage.saveNovedades([newItem, ...current]);
    return newItem;
  },

  deleteNovedad(id: string): NovedadItem[] {
    const current = storage.getNovedades();
    const updated = current.filter((n) => n.id !== id);
    storage.saveNovedades(updated);
    return updated;
  },

  likeNovedad(id: string): NovedadItem[] {
    const current = storage.getNovedades();
    const updated = current.map((n) => (n.id === id ? { ...n, likes: n.likes + 1 } : n));
    storage.saveNovedades(updated);
    return updated;
  },

  // Avatares Maestros
  getAvatares(): MasterAvatar[] {
    try {
      const data = localStorage.getItem(AVATARES_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  saveAvatares(items: MasterAvatar[]): void {
    try {
      localStorage.setItem(AVATARES_KEY, JSON.stringify(items));
    } catch (e) {
      console.error('Error guardando avatares', e);
    }
  },

  addAvatar(avatar: Omit<MasterAvatar, 'id' | 'createdAt'>): MasterAvatar {
    const current = storage.getAvatares();
    const newItem: MasterAvatar = {
      ...avatar,
      id: 'ava_' + Date.now(),
      createdAt: Date.now(),
    };
    storage.saveAvatares([newItem, ...current]);
    return newItem;
  },

  deleteAvatar(id: string): MasterAvatar[] {
    const current = storage.getAvatares();
    const updated = current.filter((a) => a.id !== id);
    storage.saveAvatares(updated);
    return updated;
  },

  // Profile
  getProfile(): UserProfile {
    try {
      const data = localStorage.getItem(PROFILE_KEY);
      return data ? { ...defaultProfile, ...JSON.parse(data) } : defaultProfile;
    } catch {
      return defaultProfile;
    }
  },

  saveProfile(profile: UserProfile): void {
    try {
      localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
    } catch (e) {
      console.error('Error guardando perfil', e);
    }
  },

  // Settings
  getSettings(): AppSettings {
    try {
      const data = localStorage.getItem(SETTINGS_KEY);
      return data ? { ...defaultSettings, ...JSON.parse(data) } : defaultSettings;
    } catch {
      return defaultSettings;
    }
  },

  saveSettings(settings: AppSettings): void {
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    } catch (e) {
      console.error('Error guardando ajustes', e);
    }
  },

  // Export & Import
  exportAllData(): string {
    return JSON.stringify({
      chats: storage.getChats(),
      novedades: storage.getNovedades(),
      avatares: storage.getAvatares(),
      profile: storage.getProfile(),
      settings: storage.getSettings(),
      exportedAt: new Date().toISOString(),
    });
  },

  importAllData(jsonStr: string): boolean {
    try {
      const parsed = JSON.parse(jsonStr);
      if (parsed.chats) storage.saveChats(parsed.chats);
      if (parsed.novedades) storage.saveNovedades(parsed.novedades);
      if (parsed.avatares) storage.saveAvatares(parsed.avatares);
      if (parsed.profile) storage.saveProfile(parsed.profile);
      if (parsed.settings) storage.saveSettings(parsed.settings);
      return true;
    } catch (e) {
      console.error('Error importando datos', e);
      return false;
    }
  },

  clearAllData(): void {
    localStorage.removeItem(CHATS_KEY);
    localStorage.removeItem(NOVEDADES_KEY);
    localStorage.removeItem(AVATARES_KEY);
    localStorage.removeItem(PROFILE_KEY);
    localStorage.removeItem(SETTINGS_KEY);
  },
};
