import React, { useState, useRef } from 'react';
import { Chat } from '../types';
import { X, Camera, Trash2, Pin, Eraser, Check } from 'lucide-react';

interface ContactEditModalProps {
  chat: Chat | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (chatId: string, updates: Partial<Chat>) => void;
  onDelete: (chatId: string) => void;
  onClearMessages: (chatId: string) => void;
  onOpenLiveCamera: () => void;
}

export const ContactEditModal: React.FC<ContactEditModalProps> = ({
  chat,
  isOpen,
  onClose,
  onSave,
  onDelete,
  onClearMessages,
  onOpenLiveCamera,
}) => {
  if (!isOpen || !chat) return null;

  const [title, setTitle] = useState(chat.title);
  const [status, setStatus] = useState(chat.status);
  const [avatarUrl, setAvatarUrl] = useState(chat.avatarUrl || '');
  const [isPinned, setIsPinned] = useState(Boolean(chat.isPinned));
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setAvatarUrl(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(chat.id, {
      title: title.trim() || 'Contacto',
      status: status.trim() || 'En línea 🌻',
      avatarUrl,
      isPinned,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
      <div className="relative w-full max-w-sm bg-white rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 bg-gradient-to-r from-amber-600 via-yellow-500 to-amber-600 text-white">
          <div className="flex items-center gap-2">
            <span className="text-xl">🌻</span>
            <h3 className="font-bold text-base">Editar Contacto / Chat</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 active:scale-95 transition"
          >
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 flex-1 overflow-y-auto space-y-4">
          {/* Avatar edit circle */}
          <div className="flex flex-col items-center justify-center gap-2">
            <div className="relative group">
              <div className="w-24 h-24 rounded-full overflow-hidden border-3 border-amber-400 bg-amber-50 shadow-inner flex items-center justify-center text-amber-700 font-bold text-2xl">
                {avatarUrl ? (
                  <img src={avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
                ) : (
                  <span>{title.charAt(0).toUpperCase() || '🌻'}</span>
                )}
              </div>
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="absolute bottom-0 right-0 p-2 bg-amber-500 text-stone-900 rounded-full shadow-lg border-2 border-white hover:bg-amber-400 active:scale-95 transition"
                title="Cambiar foto de contacto"
              >
                <Camera className="w-4 h-4" />
              </button>
            </div>

            <div className="flex items-center gap-2 mt-1">
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="text-xs text-amber-700 hover:text-amber-800 font-semibold underline"
              >
                Subir foto
              </button>
              <span className="text-stone-300">•</span>
              <button
                type="button"
                onClick={onOpenLiveCamera}
                className="text-xs text-amber-700 hover:text-amber-800 font-semibold underline"
              >
                Cámara
              </button>
              {avatarUrl && (
                <>
                  <span className="text-stone-300">•</span>
                  <button
                    type="button"
                    onClick={() => setAvatarUrl('')}
                    className="text-xs text-red-600 hover:text-red-700 font-semibold"
                  >
                    Quitar
                  </button>
                </>
              )}
            </div>

            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleFileUpload}
            />
          </div>

          {/* Name Field */}
          <div>
            <label className="block text-xs font-semibold text-stone-600 uppercase mb-1">
              Nombre del contacto o proyecto
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Ej: Cliente Sofía - Avatar Chibi"
              className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-500 text-stone-900 text-sm font-medium"
            />
          </div>

          {/* Status Field */}
          <div>
            <label className="block text-xs font-semibold text-stone-600 uppercase mb-1">
              Info / Estado del contacto
            </label>
            <input
              type="text"
              value={status}
              onChange={(e) => setStatus(e.target.value)}
              placeholder="Ej: Avatar Maestro 3D • Vestuario de gala"
              className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-500 text-stone-900 text-sm"
            />
          </div>

          {/* Pin option */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-amber-50/70 border border-amber-100">
            <div className="flex items-center gap-2.5 text-stone-800 text-sm font-medium">
              <Pin className="w-4 h-4 text-amber-600" />
              <span>Fijar en la parte superior</span>
            </div>
            <input
              type="checkbox"
              checked={isPinned}
              onChange={(e) => setIsPinned(e.target.checked)}
              className="w-4 h-4 accent-amber-600 rounded"
            />
          </div>

          {/* Danger zone actions */}
          <div className="pt-2 border-t border-stone-100 space-y-2">
            <button
              type="button"
              onClick={() => {
                if (window.confirm('¿Seguro que deseas vaciar todos los mensajes de esta conversación?')) {
                  onClearMessages(chat.id);
                  onClose();
                }
              }}
              className="w-full py-2 px-3 rounded-xl text-stone-600 hover:bg-stone-100 flex items-center justify-center gap-2 text-xs font-semibold transition"
            >
              <Eraser className="w-4 h-4 text-stone-500" />
              Vaciar mensajes de este chat
            </button>

            <button
              type="button"
              onClick={() => {
                if (window.confirm(`¿Eliminar la conversación con "${chat.title}"?`)) {
                  onDelete(chat.id);
                  onClose();
                }
              }}
              className="w-full py-2 px-3 rounded-xl text-red-600 hover:bg-red-50 flex items-center justify-center gap-2 text-xs font-semibold transition"
            >
              <Trash2 className="w-4 h-4" />
              Eliminar este chat
            </button>
          </div>

          {/* Save button */}
          <div className="pt-3">
            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-stone-950 font-bold text-sm hover:from-amber-400 hover:to-yellow-400 active:scale-98 transition flex items-center justify-center gap-2 shadow-md shadow-amber-500/20"
            >
              <Check className="w-4 h-4 stroke-[3]" />
              Guardar cambios
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
