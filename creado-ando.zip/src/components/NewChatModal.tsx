import React, { useState, useRef } from 'react';
import { X, Camera, Plus, Sparkles, Image as ImageIcon } from 'lucide-react';

interface NewChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreate: (title: string, status?: string, avatarUrl?: string, initialPrompt?: string) => void;
  onOpenLiveCamera: () => void;
}

export const NewChatModal: React.FC<NewChatModalProps> = ({
  isOpen,
  onClose,
  onCreate,
  onOpenLiveCamera,
}) => {
  if (!isOpen) return null;

  const [title, setTitle] = useState('');
  const [status, setStatus] = useState('En línea 🌻');
  const [avatarUrl, setAvatarUrl] = useState('');
  const [selectedAction, setSelectedAction] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const quickStarters = [
    {
      id: 'maestro',
      label: '👑 Avatar Maestro',
      desc: 'Crear identidad base a partir de foto',
      prompt: 'Hola! Quiero crear un Avatar Maestro consistente a partir de una foto. Te la voy a compartir para definir rasgos y estilo.',
    },
    {
      id: 'vestuario',
      label: '👗 Vestuario & Outfits',
      desc: 'Cambios de ropa y estilo',
      prompt: 'Hola! Quiero diseñar nuevas opciones de vestuario y outfits temáticos para mi avatar.',
    },
    {
      id: 'escenarios',
      label: '🌄 Escenarios & Fondos',
      desc: 'Lugares, oficinas y fantasía',
      prompt: 'Hola! Necesito componer fondos y escenarios impresionantes para colocar a mi avatar.',
    },
    {
      id: 'historieta',
      label: '📖 Historieta / Cómic',
      desc: 'Tira de viñetas con diálogos',
      prompt: 'Hola! Quiero crear una historieta o cómic de varias viñetas con guión y globos de diálogo.',
    },
    {
      id: 'video',
      label: '🎬 Video / Miniserie',
      desc: 'Guión audiovisual y escenas',
      prompt: 'Hola! Vamos a desarrollar el guión y storyboard de una miniserie o video con mi avatar.',
    },
    {
      id: 'stickers',
      label: '🏷️ Pack de Stickers',
      desc: 'Emociones para WhatsApp',
      prompt: 'Hola! Quiero diseñar un paquete de stickers con expresiones y frases para usar en WhatsApp.',
    },
    {
      id: 'publicidad',
      label: '📢 Publicidad para Vender',
      desc: 'Copies y anuncios para redes',
      prompt: 'Hola! Necesito crear publicaciones, ganchos publicitarios y copys persuasivos para vender mis avatares en redes.',
    },
  ];

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setAvatarUrl(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const chosenStarter = quickStarters.find((s) => s.id === selectedAction);
    onCreate(title.trim(), status.trim(), avatarUrl, chosenStarter?.prompt);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
      <div className="relative w-full max-w-md bg-white rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh] animate-in zoom-in-95 duration-200">
        {/* Top Header */}
        <div className="flex items-center justify-between px-5 py-4 bg-gradient-to-r from-amber-600 via-yellow-500 to-amber-600 text-white">
          <div className="flex items-center gap-2">
            <span className="text-xl">🌻</span>
            <h3 className="font-bold text-base">Nuevo Chat Creativo</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 active:scale-95 transition"
          >
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 flex-1 overflow-y-auto space-y-4">
          {/* Avatar circle */}
          <div className="flex items-center gap-4">
            <div className="relative">
              <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-amber-400 bg-amber-50 shadow-inner flex items-center justify-center text-amber-800 font-bold text-xl">
                {avatarUrl ? (
                  <img src={avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
                ) : (
                  <span>{title.charAt(0).toUpperCase() || '🌻'}</span>
                )}
              </div>
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="absolute bottom-0 right-0 p-1.5 bg-amber-500 text-stone-900 rounded-full shadow border border-white hover:bg-amber-400 active:scale-95 transition"
                title="Subir foto"
              >
                <Camera className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="flex-1 space-y-1">
              <div className="text-xs text-stone-500 font-medium">Foto del contacto o proyecto</div>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="px-2.5 py-1 rounded-lg bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold flex items-center gap-1.5"
                >
                  <ImageIcon className="w-3.5 h-3.5 text-amber-600" />
                  Galería
                </button>
                <button
                  type="button"
                  onClick={onOpenLiveCamera}
                  className="px-2.5 py-1 rounded-lg bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold flex items-center gap-1.5"
                >
                  <Camera className="w-3.5 h-3.5 text-amber-600" />
                  Cámara
                </button>
              </div>
            </div>

            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleFileUpload}
            />
          </div>

          {/* Contact / Project Name */}
          <div>
            <label className="block text-xs font-semibold text-stone-600 uppercase mb-1">
              Nombre del contacto o proyecto *
            </label>
            <input
              type="text"
              required
              autoFocus
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Ej: Cliente Sofía, Avatar Maestro 1, Miniserie..."
              className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-500 text-stone-900 text-sm font-medium"
            />
          </div>

          {/* Status */}
          <div>
            <label className="block text-xs font-semibold text-stone-600 uppercase mb-1">
              Info / Estado
            </label>
            <input
              type="text"
              value={status}
              onChange={(e) => setStatus(e.target.value)}
              placeholder="Ej: En línea 🌻, Avatar 3D en proceso..."
              className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-500 text-stone-900 text-sm"
            />
          </div>

          {/* Quick Objective / Starter */}
          <div>
            <label className="block text-xs font-semibold text-stone-600 uppercase mb-2 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              ¿Qué deseas crear en esta conversación? (Opcional)
            </label>
            <div className="grid grid-cols-1 gap-2 max-h-48 overflow-y-auto pr-1">
              {quickStarters.map((item) => {
                const isSelected = selectedAction === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setSelectedAction(isSelected ? null : item.id)}
                    className={`text-left p-2.5 rounded-xl border transition flex items-center justify-between ${
                      isSelected
                        ? 'border-amber-500 bg-amber-50 text-amber-950 font-semibold'
                        : 'border-stone-200 hover:border-amber-300 hover:bg-stone-50 text-stone-700'
                    }`}
                  >
                    <div>
                      <div className="text-xs font-bold">{item.label}</div>
                      <div className="text-[11px] text-stone-500 font-normal">{item.desc}</div>
                    </div>
                    {isSelected && (
                      <span className="text-xs bg-amber-500 text-stone-950 px-2 py-0.5 rounded-full font-bold">
                        Elegido
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Action button */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={!title.trim()}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-stone-950 font-bold text-sm hover:from-amber-400 hover:to-yellow-400 active:scale-98 transition flex items-center justify-center gap-2 shadow-md shadow-amber-500/20 disabled:opacity-50"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              Iniciar conversación
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
