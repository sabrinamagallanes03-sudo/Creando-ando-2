import React, { useRef, useState, useEffect } from 'react';
import { Camera, RefreshCw, X, Check, Image as ImageIcon } from 'lucide-react';

interface CameraModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPhotoCaptured: (base64Photo: string) => void;
  title?: string;
}

export const CameraModal: React.FC<CameraModalProps> = ({
  isOpen,
  onClose,
  onPhotoCaptured,
  title = 'Cámara de Creado Ando',
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [capturedPhoto, setCapturedPhoto] = useState<string | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) {
      stopCamera();
      setCapturedPhoto(null);
      return;
    }

    startCamera(facingMode);

    return () => {
      stopCamera();
    };
  }, [isOpen, facingMode]);

  const startCamera = async (mode: 'user' | 'environment') => {
    stopCamera();
    setCameraError(null);
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: mode, width: { ideal: 1280 }, height: { ideal: 1280 } },
        audio: false,
      });
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (err: any) {
      console.warn('Error accediendo a la cámara:', err);
      setCameraError('No se pudo acceder a la cámara en vivo. Puedes subir una foto desde tu galería.');
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach((track) => track.stop());
      setStream(null);
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  };

  const switchCamera = () => {
    setFacingMode((prev) => (prev === 'user' ? 'environment' : 'user'));
  };

  const takePhoto = () => {
    if (!videoRef.current) return;
    const video = videoRef.current;
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 640;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    if (facingMode === 'user') {
      // Mirror front camera
      ctx.translate(canvas.width, 0);
      ctx.scale(-1, 1);
    }
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.9);
    setCapturedPhoto(dataUrl);
    stopCamera();
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setCapturedPhoto(reader.result);
          stopCamera();
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const confirmPhoto = () => {
    if (capturedPhoto) {
      onPhotoCaptured(capturedPhoto);
      onClose();
    }
  };

  const retakePhoto = () => {
    setCapturedPhoto(null);
    startCamera(facingMode);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-sm p-3">
      <div className="relative w-full max-w-md bg-stone-900 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
        {/* Top Header */}
        <div className="flex items-center justify-between p-4 bg-gradient-to-r from-amber-600 to-yellow-600 text-white">
          <div className="flex items-center gap-2">
            <span className="text-xl">🌻</span>
            <h3 className="font-semibold text-base">{title}</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 active:scale-95 transition"
            aria-label="Cerrar cámara"
          >
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* Viewport / Preview */}
        <div className="relative w-full aspect-square bg-black flex items-center justify-center overflow-hidden">
          {capturedPhoto ? (
            <img
              src={capturedPhoto}
              alt="Captura"
              className="w-full h-full object-cover animate-in fade-in duration-200"
            />
          ) : cameraError ? (
            <div className="p-6 text-center text-amber-100 flex flex-col items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-amber-500/20 flex items-center justify-center text-amber-300">
                <Camera className="w-8 h-8" />
              </div>
              <p className="text-sm">{cameraError}</p>
              <button
                onClick={() => fileInputRef.current?.click()}
                className="px-4 py-2.5 rounded-full bg-amber-500 text-stone-900 font-semibold text-sm hover:bg-amber-400 active:scale-95 transition flex items-center gap-2 shadow-lg"
              >
                <ImageIcon className="w-4 h-4" />
                Elegir foto de la galería
              </button>
            </div>
          ) : (
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className={`w-full h-full object-cover ${facingMode === 'user' ? 'scale-x-[-1]' : ''}`}
            />
          )}

          {/* Guidelines overlay for avatar portraits */}
          {!capturedPhoto && !cameraError && (
            <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
              <div className="w-48 h-56 rounded-full border-2 border-dashed border-amber-300/60 shadow-[0_0_15px_rgba(251,191,36,0.3)] flex items-center justify-center">
                <span className="text-xs text-amber-200/80 bg-black/40 px-2 py-0.5 rounded-full">
                  Encuadre de Avatar
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Controls */}
        <div className="p-5 bg-stone-950 flex items-center justify-around">
          {capturedPhoto ? (
            <>
              <button
                onClick={retakePhoto}
                className="flex flex-col items-center gap-1 text-xs text-stone-300 hover:text-white"
              >
                <div className="w-12 h-12 rounded-full bg-stone-800 flex items-center justify-center">
                  <RefreshCw className="w-5 h-5" />
                </div>
                Repetir
              </button>

              <button
                onClick={confirmPhoto}
                className="flex flex-col items-center gap-1 text-xs text-amber-400 font-bold"
              >
                <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-amber-500 to-yellow-400 text-stone-950 flex items-center justify-center shadow-lg shadow-amber-500/30 active:scale-95 transition">
                  <Check className="w-8 h-8 stroke-[3]" />
                </div>
                Usar foto
              </button>
            </>
          ) : (
            <>
              <button
                onClick={() => fileInputRef.current?.click()}
                className="flex flex-col items-center gap-1 text-xs text-stone-300 hover:text-white"
                title="Galería"
              >
                <div className="w-12 h-12 rounded-full bg-stone-800 flex items-center justify-center active:scale-95 transition">
                  <ImageIcon className="w-5 h-5 text-amber-300" />
                </div>
                Galería
              </button>

              <button
                onClick={takePhoto}
                disabled={Boolean(cameraError)}
                className="w-16 h-16 rounded-full border-4 border-white p-1 flex items-center justify-center active:scale-95 transition disabled:opacity-40"
              >
                <div className="w-full h-full rounded-full bg-amber-400 shadow-md" />
              </button>

              <button
                onClick={switchCamera}
                disabled={Boolean(cameraError)}
                className="flex flex-col items-center gap-1 text-xs text-stone-300 hover:text-white disabled:opacity-40"
                title="Cambiar cámara"
              >
                <div className="w-12 h-12 rounded-full bg-stone-800 flex items-center justify-center active:scale-95 transition">
                  <RefreshCw className="w-5 h-5" />
                </div>
                Girar
              </button>
            </>
          )}

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={handleFileUpload}
          />
        </div>
      </div>
    </div>
  );
};
