import React, { useState } from 'react';
import { X, Share2, Download, Copy, Check, MessageCircle, Instagram, Facebook } from 'lucide-react';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  text?: string;
  imageUrl?: string;
}

export const ShareModal: React.FC<ShareModalProps> = ({
  isOpen,
  onClose,
  title,
  text = '',
  imageUrl,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const shareText = `${title}\n${text ? text + '\n' : ''}✨ Creado con Creado Ando 🌻`;

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title,
          text: shareText,
          url: window.location.href,
        });
      } catch (e) {
        console.warn('Share cancelled or failed', e);
      }
    } else {
      copyToClipboard();
    }
  };

  const shareToWhatsApp = () => {
    const encoded = encodeURIComponent(shareText);
    const url = `https://api.whatsapp.com/send?text=${encoded}`;
    window.open(url, '_blank');
  };

  const shareToFacebook = () => {
    const encodedUrl = encodeURIComponent(window.location.href);
    const url = `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}&quote=${encodeURIComponent(shareText)}`;
    window.open(url, '_blank');
  };

  const shareToInstagram = () => {
    // Instagram doesn't have a direct web post URL, so we copy content & prompt download
    copyToClipboard();
    if (imageUrl) {
      downloadImage();
    }
    alert('¡Texto copiado e imagen descargada! Ya puedes abrir Instagram y publicarlo en tus Historias o Feed 🌻');
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(shareText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const downloadImage = () => {
    if (!imageUrl) return;
    const a = document.createElement('a');
    a.href = imageUrl;
    a.download = `creado-ando-${Date.now()}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
      <div className="relative w-full max-w-sm bg-white rounded-3xl overflow-hidden shadow-2xl flex flex-col animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 bg-gradient-to-r from-amber-600 to-yellow-600 text-white">
          <div className="flex items-center gap-2">
            <span className="text-xl">🌻</span>
            <h3 className="font-bold text-base">Compartir en Redes</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 active:scale-95 transition"
          >
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* Content Preview */}
        <div className="p-5 space-y-4">
          {imageUrl && (
            <div className="w-full aspect-square max-h-56 rounded-2xl overflow-hidden bg-stone-100 border border-stone-200 shadow-sm flex items-center justify-center">
              <img src={imageUrl} alt="Contenido" className="w-full h-full object-cover" />
            </div>
          )}

          <div>
            <h4 className="font-bold text-stone-900 text-sm line-clamp-1">{title}</h4>
            {text && <p className="text-xs text-stone-600 line-clamp-2 mt-0.5">{text}</p>}
          </div>

          {/* Social Buttons Grid */}
          <div className="grid grid-cols-3 gap-3 pt-2">
            {/* WhatsApp */}
            <button
              onClick={shareToWhatsApp}
              className="flex flex-col items-center justify-center gap-1.5 p-3 rounded-2xl bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-800 transition active:scale-95"
            >
              <div className="w-10 h-10 rounded-full bg-emerald-600 text-white flex items-center justify-center shadow-md">
                <MessageCircle className="w-5 h-5" />
              </div>
              <span className="text-xs font-semibold">WhatsApp</span>
            </button>

            {/* Instagram */}
            <button
              onClick={shareToInstagram}
              className="flex flex-col items-center justify-center gap-1.5 p-3 rounded-2xl bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-800 transition active:scale-95"
            >
              <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-yellow-500 via-rose-500 to-purple-600 text-white flex items-center justify-center shadow-md">
                <Instagram className="w-5 h-5" />
              </div>
              <span className="text-xs font-semibold">Instagram</span>
            </button>

            {/* Facebook */}
            <button
              onClick={shareToFacebook}
              className="flex flex-col items-center justify-center gap-1.5 p-3 rounded-2xl bg-blue-50 hover:bg-blue-100 border border-blue-200 text-blue-800 transition active:scale-95"
            >
              <div className="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-md">
                <Facebook className="w-5 h-5" />
              </div>
              <span className="text-xs font-semibold">Facebook</span>
            </button>
          </div>

          {/* Action Tools */}
          <div className="pt-2 border-t border-stone-100 space-y-2">
            <button
              onClick={handleNativeShare}
              className="w-full py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition active:scale-98"
            >
              <Share2 className="w-4 h-4" />
              Más opciones de compartir en el celular
            </button>

            <div className="flex gap-2">
              <button
                onClick={copyToClipboard}
                className="flex-1 py-2 px-3 rounded-xl border border-stone-300 hover:bg-stone-50 text-stone-700 font-semibold text-xs flex items-center justify-center gap-1.5 transition active:scale-98"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? '¡Copiado!' : 'Copiar texto'}
              </button>

              {imageUrl && (
                <button
                  onClick={downloadImage}
                  className="flex-1 py-2 px-3 rounded-xl border border-stone-300 hover:bg-stone-50 text-stone-700 font-semibold text-xs flex items-center justify-center gap-1.5 transition active:scale-98"
                >
                  <Download className="w-3.5 h-3.5" />
                  Descargar imagen
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
