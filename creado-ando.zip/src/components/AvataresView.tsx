import React, { useState, useRef } from 'react';
import { MasterAvatar } from '../types';
import { Plus, MessageSquare, Trash2, Share2, Sparkles, Image as ImageIcon, Camera } from 'lucide-react';
import { ShareModal } from './ShareModal';

interface AvataresViewProps {
  avatares: MasterAvatar[];
  onAddAvatar: (avatar: Omit<MasterAvatar, 'id' | 'createdAt'>) => void;
  onDeleteAvatar: (id: string) => void;
  onOpenChatWithAvatar: (avatar: MasterAvatar) => void;
  onOpenLiveCamera: () => void;
}

export const AvataresView: React.FC<AvataresViewProps> = ({
  avatares,
  onAddAvatar,
  onDeleteAvatar,
  onOpenChatWithAvatar,
  onOpenLiveCamera,
}) => {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedShareAvatar, setSelectedShareAvatar] = useState<MasterAvatar | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [style, setStyle] = useState('3D Pixar / Disney');
  const [features, setFeatures] = useState('');
  const [notes, setNotes] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const styleOptions = [
    '3D Pixar / Disney',
    'Anime Shonen / Shojo',
    'Caricatura Chibi Cute',
    'Hiperrealista 4K',
    'Ilustración Cómic / Gráfica',
    'Vectorial 2D Moderno',
  ];

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setImageUrl(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !imageUrl) {
      alert('Por favor añade un nombre y una imagen para tu Avatar Maestro.');
      return;
    }

    onAddAvatar({
      name: name.trim(),
      style,
      features: features.trim() || 'Rasgos base consistentes',
      notes: notes.trim(),
      imageUrl,
    });

    setName('');
    setFeatures('');
    setNotes('');
    setImageUrl('');
    setIsAddModalOpen(false);
  };

  return (
    <div className="flex-1 overflow-y-auto bg-stone-50 pb-20">
      {/* Header Bar */}
      <div className="bg-white p-4 border-b border-stone-200 flex items-center justify-between">
        <div>
          <h3 className="font-bold text-stone-900 text-sm">Mis Avatares Maestros</h3>
          <p className="text-xs text-stone-500">
            Modelos de referencia con los que trabajas ({avatares.length})
          </p>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="px-3.5 py-1.5 rounded-full bg-amber-500 text-stone-950 font-bold text-xs hover:bg-amber-400 active:scale-95 transition shadow-xs flex items-center gap-1.5"
        >
          <Plus className="w-3.5 h-3.5 stroke-[3]" />
          Nuevo Avatar
        </button>
      </div>

      {/* Grid of Avatars */}
      <div className="p-4 max-w-lg mx-auto">
        {avatares.length === 0 ? (
          <div className="py-14 px-6 text-center flex flex-col items-center justify-center bg-white rounded-3xl border border-stone-200/80 shadow-xs">
            <div className="w-20 h-20 rounded-full bg-amber-50 border border-amber-200 flex items-center justify-center text-3xl mb-4 shadow-inner">
              👑
            </div>
            <h4 className="font-bold text-stone-900 text-base mb-1.5">
              Sin Avatares Maestros guardados aún
            </h4>
            <p className="text-xs text-stone-500 max-w-xs leading-relaxed mb-5">
              Aquí solo verás los avatares maestros con los que trabajas. Puedes crearlos chateando con la
              IA y presionando &ldquo;Guardar en Avatares Maestros&rdquo; o registrar uno directamente.
            </p>
            <button
              onClick={() => setIsAddModalOpen(true)}
              className="px-5 py-2.5 rounded-full bg-gradient-to-r from-amber-500 to-yellow-500 text-stone-950 font-bold text-xs hover:from-amber-400 hover:to-yellow-400 active:scale-95 transition shadow-md shadow-amber-500/20 flex items-center gap-2"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              Guardar un Avatar Maestro
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {avatares.map((avatar) => (
              <div
                key={avatar.id}
                className="bg-white rounded-2xl overflow-hidden border border-stone-200 shadow-xs hover:shadow-md transition flex flex-col"
              >
                {/* Image */}
                <div className="relative aspect-square bg-stone-100 overflow-hidden group">
                  <img
                    src={avatar.imageUrl}
                    alt={avatar.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                  />
                  <div className="absolute top-2 left-2 px-2.5 py-0.5 rounded-full bg-black/60 backdrop-blur-xs text-white text-[10px] font-semibold">
                    {avatar.style}
                  </div>
                  <button
                    onClick={() => {
                      if (window.confirm(`¿Eliminar al Avatar Maestro "${avatar.name}"?`)) {
                        onDeleteAvatar(avatar.id);
                      }
                    }}
                    className="absolute top-2 right-2 p-1.5 bg-black/60 text-white rounded-full hover:bg-red-600 transition"
                    title="Eliminar"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Details */}
                <div className="p-3.5 flex-1 flex flex-col justify-between space-y-2.5">
                  <div>
                    <h4 className="font-bold text-stone-900 text-sm">{avatar.name}</h4>
                    {avatar.features && (
                      <p className="text-xs text-stone-500 line-clamp-2 mt-0.5">
                        {avatar.features}
                      </p>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="space-y-1.5 pt-2 border-t border-stone-100">
                    <button
                      onClick={() => onOpenChatWithAvatar(avatar)}
                      className="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-stone-950 font-bold text-xs hover:from-amber-400 hover:to-yellow-400 active:scale-95 transition flex items-center justify-center gap-1.5 shadow-xs"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      Crear contenido en chat
                    </button>

                    <button
                      onClick={() => setSelectedShareAvatar(avatar)}
                      className="w-full py-1.5 px-3 rounded-xl border border-stone-200 hover:bg-stone-50 text-stone-700 font-semibold text-xs transition flex items-center justify-center gap-1.5"
                    >
                      <Share2 className="w-3 h-3 text-amber-600" />
                      Compartir avatar
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add Avatar Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="relative w-full max-w-md bg-white rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh] animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between px-5 py-4 bg-gradient-to-r from-amber-600 to-yellow-600 text-white">
              <div className="flex items-center gap-2">
                <span className="text-xl">👑</span>
                <h3 className="font-bold text-base">Registrar Avatar Maestro</h3>
              </div>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-1.5 rounded-full hover:bg-white/20 active:scale-95 transition"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-5 flex-1 overflow-y-auto space-y-4">
              {/* Media Picker */}
              <div>
                <label className="block text-xs font-semibold text-stone-600 uppercase mb-1.5">
                  Foto o ilustración del Avatar Maestro *
                </label>
                {imageUrl ? (
                  <div className="relative aspect-square max-h-52 mx-auto rounded-2xl overflow-hidden bg-stone-100 border border-stone-200">
                    <img src={imageUrl} alt="Avatar Maestro" className="w-full h-full object-cover" />
                    <button
                      type="button"
                      onClick={() => setImageUrl('')}
                      className="absolute top-2 right-2 p-1.5 bg-black/70 text-white rounded-full hover:bg-black transition"
                    >
                      ✕
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="p-5 rounded-2xl border-2 border-dashed border-stone-300 hover:border-amber-400 bg-stone-50 hover:bg-amber-50/50 flex flex-col items-center justify-center gap-2 text-stone-600 transition"
                    >
                      <ImageIcon className="w-6 h-6 text-amber-600" />
                      <span className="text-xs font-bold">Subir de Galería</span>
                    </button>
                    <button
                      type="button"
                      onClick={onOpenLiveCamera}
                      className="p-5 rounded-2xl border-2 border-dashed border-stone-300 hover:border-amber-400 bg-stone-50 hover:bg-amber-50/50 flex flex-col items-center justify-center gap-2 text-stone-600 transition"
                    >
                      <Camera className="w-6 h-6 text-amber-600" />
                      <span className="text-xs font-bold">Sacar Foto</span>
                    </button>
                  </div>
                )}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleFileUpload}
                />
              </div>

              {/* Name */}
              <div>
                <label className="block text-xs font-semibold text-stone-600 uppercase mb-1">
                  Nombre del Avatar *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Ej: Sofía 3D, Lucas Chibi, Reina Solar"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-500 text-stone-900 text-sm font-medium"
                />
              </div>

              {/* Style */}
              <div>
                <label className="block text-xs font-semibold text-stone-600 uppercase mb-1">
                  Estilo Visual
                </label>
                <select
                  value={style}
                  onChange={(e) => setStyle(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-500 text-stone-900 text-sm font-medium bg-white"
                >
                  {styleOptions.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>

              {/* Features */}
              <div>
                <label className="block text-xs font-semibold text-stone-600 uppercase mb-1">
                  Rasgos Físicos Clave (para mantener consistencia)
                </label>
                <textarea
                  rows={2}
                  value={features}
                  onChange={(e) => setFeatures(e.target.value)}
                  placeholder="Ej: Ojos avellana, cabello castaño ondulado con mechas doradas, sonrisa tierna..."
                  className="w-full px-3.5 py-2 rounded-xl border border-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-500 text-stone-900 text-xs"
                />
              </div>

              {/* Submit */}
              <div className="pt-2">
                <button
                  type="submit"
                  disabled={!name.trim() || !imageUrl}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-stone-950 font-bold text-sm hover:from-amber-400 hover:to-yellow-400 active:scale-98 transition flex items-center justify-center gap-2 shadow-md shadow-amber-500/20 disabled:opacity-50"
                >
                  <Plus className="w-4 h-4 stroke-[3]" />
                  Guardar Avatar Maestro
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Share Modal */}
      {selectedShareAvatar && (
        <ShareModal
          isOpen={Boolean(selectedShareAvatar)}
          onClose={() => setSelectedShareAvatar(null)}
          title={`Avatar Maestro: ${selectedShareAvatar.name}`}
          text={`Estilo: ${selectedShareAvatar.style}\n${selectedShareAvatar.features}`}
          imageUrl={selectedShareAvatar.imageUrl}
        />
      )}
    </div>
  );
};
