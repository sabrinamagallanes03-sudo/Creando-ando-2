import React, { useState } from 'react';
import { Smile, Heart, Flower2, Shirt, Palette, Sparkles, Hand, X, Search } from 'lucide-react';

interface WhatsAppEmojiPickerProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectEmoji: (emoji: string) => void;
}

type EmojiCategory = 'smileys' | 'gestures' | 'hearts' | 'nature' | 'fashion' | 'creative' | 'symbols';

const EMOJI_DATA: Record<EmojiCategory, { name: string; icon: any; list: string[] }> = {
  smileys: {
    name: 'Caritas',
    icon: Smile,
    list: [
      '😀', '😃', '😄', '😁', '😆', '😅', '😂', '🤣', '🙂', '🙃', '😉', '😊', '😇',
      '🥰', '😍', '🤩', '😘', '😗', '😚', '😙', '😋', '😛', '😜', '🤪', '😝', '🤑',
      '🤗', '🤭', '🤫', '🤔', '🤐', '🤨', '😐', '😑', '😶', '😏', '😒', '🙄', '😬',
      '🤥', '😌', '😔', '😪', '🤤', '😴', '😷', '🤒', '🤕', '🤢', '🤮', '🤧', '🥵',
      '🥶', '🥴', '😵', '🤯', '🤠', '🥳', '🥸', '😎', '🤓', '🧐', '😕', '😟', '🙁',
      '😮', '😯', '😲', '😳', '🥺', '😦', '😧', '😨', '😰', '😥', '😢', '😭', '😱',
      '😖', '😣', '😞', '😓', '😩', '😫', '🥱', '😤', '😡', '😠', '🤬', '😈', '👿',
      '💀', '💩', '🤡', '👻', '👽', '🤖'
    ],
  },
  gestures: {
    name: 'Gestos',
    icon: Hand,
    list: [
      '👋', '🤚', '🖐️', '✋', '🖖', '👌', '🤌', '🤏', '✌️', '🤞', '🤟', '🤘', '🤙',
      '👈', '👉', '👆', '🖕', '👇', '☝️', '👍', '👎', '✊', '👊', '🤛', '🤜', '👏',
      '🙌', '👐', '🤲', '🤝', '🙏', '✍️', '💅', '🤳', '💪', '🦾', '🦿', '🦵', '🦶',
      '👂', '🦻', '👃', '🧠', '🫀', '🫁', '🦷', '🦴', '👀', '👁️', '👅', '👄'
    ],
  },
  hearts: {
    name: 'Amor',
    icon: Heart,
    list: [
      '❤️', '🧡', '💛', '💚', '💙', '💜', '🖤', '🤍', '🤎', '💔', '❤️‍🔥', '❤️‍🩹', '❣️',
      '💕', '💞', '💓', '💗', '💖', '💘', '💝', '💟', '💌', '💐', '🌹', '🥀', '💋'
    ],
  },
  nature: {
    name: 'Flores',
    icon: Flower2,
    list: [
      '🌻', '🌼', '🌸', '🌺', '🌹', '🌷', '💐', '🌾', '🌿', '🍀', '🍁', '🍂', '🍃',
      '🌱', '🪴', '🌴', '🌵', '🌲', '🌳', '🍄', '🌞', '🌝', '🌛', '🌜', '🌙', '⭐',
      '🌟', '✨', '⚡', '🌈', '⛅', '☀️', '🌤️', '🌥️', '🌦️', '🌧️', '⛈️', '🌩️', '❄️'
    ],
  },
  fashion: {
    name: 'Moda',
    icon: Shirt,
    list: [
      '👑', '👒', '🧢', '🎩', '🎓', '🕶️', '🥽', '🥼', '🦺', '👔', '👕', '👖', '🧣',
      '🧤', '🧥', '🧦', '👗', '👘', '🥻', '🩱', '🩲', '🩳', '👙', '👚', '👛', '👜',
      '👝', '🎒', '👞', '👟', '👠', '👡', '🩰', '👢', '💍', '💄', '💎', '📿'
    ],
  },
  creative: {
    name: 'Arte',
    icon: Palette,
    list: [
      '🎨', '🎭', '🎬', '📽️', '📸', '📹', '📼', '📺', '📻', '🎙️', '🎤', '🎧', '🎷',
      '🎸', '🎹', '🎺', '🎻', '🪕', '🥁', '🎮', '🕹️', '🎰', '🎲', '🧩', '🪄', '🔮'
    ],
  },
  symbols: {
    name: 'Símbolos',
    icon: Sparkles,
    list: [
      '✨', '💡', '🔔', '📢', '📣', '💬', '💭', '🗯️', '📦', '🎁', '🏆', '🥇', '🥈',
      '🥉', '🎯', '🚀', '✈️', '🛒', '💰', '💵', '💯', '🔥', '🎉', '🎊', '🎈', '⭐'
    ],
  },
};

export const WhatsAppEmojiPicker: React.FC<WhatsAppEmojiPickerProps> = ({
  isOpen,
  onClose,
  onSelectEmoji,
}) => {
  if (!isOpen) return null;

  const [activeCategory, setActiveCategory] = useState<EmojiCategory>('smileys');
  const [search, setSearch] = useState('');

  const currentCategoryData = EMOJI_DATA[activeCategory];

  const displayedEmojis = search.trim()
    ? Object.values(EMOJI_DATA)
        .flatMap((cat) => cat.list)
        .filter((emoji, index, self) => self.indexOf(emoji) === index)
    : currentCategoryData.list;

  return (
    <div className="absolute bottom-16 left-2 right-2 sm:left-4 sm:right-4 z-40 bg-white/98 backdrop-blur-md rounded-2xl shadow-2xl border border-stone-200 overflow-hidden flex flex-col h-72 animate-in slide-in-from-bottom-3 duration-200">
      {/* Top Search & Close Bar */}
      <div className="flex items-center gap-2 px-3 pt-2.5 pb-1.5 border-b border-stone-100">
        <div className="flex-1 flex items-center gap-2 bg-stone-100 rounded-full px-3 py-1 text-xs text-stone-700">
          <Search className="w-3.5 h-3.5 text-stone-400 shrink-0" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar emojis como en WhatsApp..."
            className="w-full bg-transparent focus:outline-none text-xs text-stone-800 placeholder-stone-400"
          />
          {search && (
            <button onClick={() => setSearch('')} className="text-stone-400 hover:text-stone-600">
              <X className="w-3 h-3" />
            </button>
          )}
        </div>

        <button
          onClick={onClose}
          className="p-1 rounded-full text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition"
          title="Cerrar panel de emojis"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Category Tabs (Like authentic WhatsApp emoji bar) */}
      {!search && (
        <div className="flex items-center justify-around px-2 py-1 bg-stone-50 border-b border-stone-100 text-stone-500">
          {(Object.keys(EMOJI_DATA) as EmojiCategory[]).map((catKey) => {
            const cat = EMOJI_DATA[catKey];
            const Icon = cat.icon;
            const isSelected = activeCategory === catKey;
            return (
              <button
                key={catKey}
                onClick={() => setActiveCategory(catKey)}
                className={`p-1.5 rounded-lg transition relative ${
                  isSelected
                    ? 'text-amber-600 bg-amber-50 font-bold'
                    : 'text-stone-400 hover:text-stone-700'
                }`}
                title={cat.name}
              >
                <Icon className="w-4 h-4" />
                {isSelected && (
                  <div className="absolute bottom-0 left-1 right-1 h-0.5 bg-amber-500 rounded-full" />
                )}
              </button>
            );
          })}
        </div>
      )}

      {/* Emojis Grid */}
      <div className="flex-1 overflow-y-auto p-3 grid grid-cols-8 sm:grid-cols-10 gap-1 content-start select-none">
        {displayedEmojis.map((emoji, index) => (
          <button
            key={`${emoji}-${index}`}
            type="button"
            onClick={() => onSelectEmoji(emoji)}
            className="text-2xl hover:scale-125 active:scale-95 transition-transform flex items-center justify-center p-1 rounded-lg hover:bg-amber-50"
          >
            {emoji}
          </button>
        ))}
      </div>
    </div>
  );
};
