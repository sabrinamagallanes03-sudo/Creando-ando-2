import React, { useState, useRef } from 'react';
import { AppSettings, HeaderSunflowerStyle, UserProfile, AIEngineProvider } from '../types';
import {
  X,
  Palette,
  Image as ImageIcon,
  Type,
  Download,
  Upload,
  Trash2,
  Check,
  Sparkles,
  Cpu,
} from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  profile: UserProfile;
  onSaveSettings: (settings: AppSettings) => void;
  onOpenProfile: () => void;
  onExportData: () => void;
  onImportData: (jsonStr: string) => boolean;
  onClearData: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  profile,
  onSaveSettings,
  onOpenProfile,
  onExportData,
  onImportData,
  onClearData,
}) => {
  if (!isOpen) return null;

  const [headerStyle, setHeaderStyle] = useState<HeaderSunflowerStyle>(settings.headerStyle);
  const [chatWallpaperOpacity, setChatWallpaperOpacity] = useState<number>(settings.chatWallpaperOpacity);
  const [chatWallpaperBg, setChatWallpaperBg] = useState<string>(settings.chatWallpaperBg);
  const [fontSize, setFontSize] = useState<'sm' | 'base' | 'lg'>(settings.fontSize);
  const [themeMode, setThemeMode] = useState<'sunflower-clean' | 'warm-gold' | 'light-classic'>(
    settings.themeMode
  );
  const [aiEngine, setAiEngine] = useState<AIEngineProvider>(settings.aiEngine || 'auto');
  const [customHeaderImageUrl, setCustomHeaderImageUrl] = useState<string>(
    settings.customHeaderImageUrl || ''
  );
  const [customWallpaperImageUrl, setCustomWallpaperImageUrl] = useState<string>(
    settings.customWallpaperImageUrl || ''
  );
  const [referenceDesignImage, setReferenceDesignImage] = useState<string>(
    settings.referenceDesignImage || ''
  );
  const [referenceDesignNotes, setReferenceDesignNotes] = useState<string>(
    settings.referenceDesignNotes || ''
  );
  const fileImportRef = useRef<HTMLInputElement | null>(null);
  const referenceFileInputRef = useRef<HTMLInputElement | null>(null);

  const handleReferenceImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          const resultStr = reader.result;
          setReferenceDesignImage(resultStr);
          setCustomHeaderImageUrl(resultStr);
          setCustomWallpaperImageUrl(resultStr);
          setHeaderStyle('imagen-personalizada');
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const sunflowerStyles: { id: HeaderSunflowerStyle; name: string; desc: string; previewColor: string }[] = [
    {
      id: 'girasoles-dorados',
      name: 'Girasoles Dorados Radiantes',
      desc: 'Patrón vívido de girasoles amarillos y ámbar con hojas verdes',
      previewColor: 'from-amber-600 via-yellow-500 to-amber-700',
    },
    {
      id: 'girasoles-acuarela',
      name: 'Acuarela de Girasoles',
      desc: 'Diseño suave y luminoso con tonos miel y luz solar',
      previewColor: 'from-amber-500 via-yellow-400 to-orange-500',
    },
    {
      id: 'girasoles-botanico',
      name: 'Girasoles Botánico & Jardín',
      desc: 'Flores amarillas entrelazadas con follaje verde esmeralda',
      previewColor: 'from-emerald-800 via-amber-600 to-yellow-600',
    },
    {
      id: 'girasoles-vintage',
      name: 'Girasoles Vintage Rústico',
      desc: 'Flores en tonos dorados cálidos y café ámbar relajante',
      previewColor: 'from-amber-800 via-yellow-700 to-amber-900',
    },
    {
      id: 'girasoles-noche',
      name: 'Noche de Girasoles Brillantes',
      desc: 'Contraste elegante de girasoles luminosos sobre fondo oscuro',
      previewColor: 'from-slate-900 via-amber-950 to-slate-900',
    },
    ...(customHeaderImageUrl
      ? [
          {
            id: 'imagen-personalizada' as HeaderSunflowerStyle,
            name: '🖼️ Mi Imagen de Diseño Personalizada',
            desc: 'Fondo basado en la imagen que subiste como ejemplo',
            previewColor: 'from-amber-600 via-stone-700 to-amber-900',
          },
        ]
      : []),
  ];

  const wallpaperBackgrounds = [
    { label: 'Crema Clásico WhatsApp', color: '#efeae2' },
    { label: 'Blanco Lino Limpio', color: '#f9f8f6' },
    { label: 'Luz Cálida Suave', color: '#fffdfa' },
    { label: 'Girasol Pastel', color: '#fef9c3' },
  ];

  const handleSave = () => {
    onSaveSettings({
      headerStyle,
      chatWallpaperOpacity,
      chatWallpaperBg,
      fontSize,
      themeMode,
      aiEngine,
      customHeaderImageUrl,
      customWallpaperImageUrl,
      referenceDesignImage,
      referenceDesignNotes,
    });
    onClose();
  };

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result as string;
        if (content) {
          const success = onImportData(content);
          if (success) {
            alert('¡Datos restaurados con éxito! 🌻');
            onClose();
          } else {
            alert('El archivo no tiene el formato correcto.');
          }
        }
      };
      reader.readAsText(file);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
      <div className="relative w-full max-w-md bg-stone-50 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh] animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 bg-gradient-to-r from-amber-600 via-yellow-500 to-amber-600 text-white">
          <div className="flex items-center gap-2">
            <span className="text-xl">🌻</span>
            <h3 className="font-bold text-base">Ajustes & Personalización</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 active:scale-95 transition"
          >
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        <div className="p-5 flex-1 overflow-y-auto space-y-5 text-stone-800">
          {/* User Profile Quick Banner */}
          <div
            onClick={() => {
              onClose();
              onOpenProfile();
            }}
            className="flex items-center gap-3 p-3 bg-white rounded-2xl border border-stone-200 shadow-xs cursor-pointer hover:border-amber-400 transition"
          >
            <div className="w-12 h-12 rounded-full overflow-hidden bg-amber-100 border border-amber-300 flex items-center justify-center text-amber-800 font-bold text-lg">
              {profile.avatarUrl ? (
                <img src={profile.avatarUrl} alt="Foto" className="w-full h-full object-cover" />
              ) : (
                <span>{profile.name.charAt(0).toUpperCase()}</span>
              )}
            </div>
            <div className="flex-1">
              <h4 className="font-bold text-sm text-stone-900">{profile.name}</h4>
              <p className="text-xs text-stone-500 truncate">{profile.status}</p>
            </div>
            <span className="text-xs font-semibold text-amber-700 bg-amber-50 px-2.5 py-1 rounded-full border border-amber-200">
              Editar
            </span>
          </div>

          {/* Subir Imagen de Referencia de Diseño */}
          <div className="p-4 bg-gradient-to-r from-amber-500/10 via-yellow-400/15 to-amber-500/10 rounded-2xl border-2 border-dashed border-amber-400">
            <div className="flex items-center gap-2 mb-1.5">
              <span className="text-lg">🎨</span>
              <h4 className="font-bold text-sm text-stone-900">
                Sube tu Imagen de Ejemplo para el Diseño
              </h4>
            </div>
            <p className="text-xs text-stone-600 mb-3 leading-relaxed">
              Sube aquí cualquier imagen o captura de pantalla que tengas para que la usemos como ejemplo visual del diseño que deseas para la aplicación.
            </p>

            {referenceDesignImage ? (
              <div className="space-y-3">
                <div className="relative aspect-video rounded-xl overflow-hidden bg-stone-100 border border-amber-300 shadow-sm">
                  <img
                    src={referenceDesignImage}
                    alt="Diseño de referencia"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-2 right-2 flex gap-1">
                    <button
                      type="button"
                      onClick={() => {
                        setReferenceDesignImage('');
                        setCustomHeaderImageUrl('');
                        setCustomWallpaperImageUrl('');
                        if (headerStyle === 'imagen-personalizada') {
                          setHeaderStyle('girasoles-dorados');
                        }
                      }}
                      className="p-1.5 bg-black/70 text-white rounded-full hover:bg-black transition"
                      title="Quitar imagen"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Quick toggle actions */}
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <button
                    type="button"
                    onClick={() => {
                      setCustomHeaderImageUrl(referenceDesignImage);
                      setHeaderStyle('imagen-personalizada');
                      alert('¡Imagen aplicada a la barra superior de la app! 🌻');
                    }}
                    className={`py-2 px-2.5 rounded-xl border text-center font-bold transition ${
                      headerStyle === 'imagen-personalizada'
                        ? 'bg-amber-500 text-stone-950 border-amber-500 shadow-xs'
                        : 'bg-white hover:bg-amber-50 text-stone-700 border-stone-200'
                    }`}
                  >
                    🌻 Usar en barra superior
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setCustomWallpaperImageUrl(referenceDesignImage);
                      alert('¡Imagen aplicada como fondo de los chats! 🌻');
                    }}
                    className={`py-2 px-2.5 rounded-xl border text-center font-bold transition ${
                      customWallpaperImageUrl === referenceDesignImage
                        ? 'bg-amber-500 text-stone-950 border-amber-500 shadow-xs'
                        : 'bg-white hover:bg-amber-50 text-stone-700 border-stone-200'
                    }`}
                  >
                    💬 Usar de fondo en chat
                  </button>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-stone-600 mb-1">
                    Notas sobre cómo quieres que se aplique tu diseño:
                  </label>
                  <textarea
                    rows={2}
                    value={referenceDesignNotes}
                    onChange={(e) => setReferenceDesignNotes(e.target.value)}
                    placeholder="Ej: Me gustan estos colores amarillos, la forma de los botones, la tipografía..."
                    className="w-full px-3 py-1.5 rounded-xl border border-stone-300 text-xs text-stone-800 bg-white"
                  />
                </div>
              </div>
            ) : (
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => referenceFileInputRef.current?.click()}
                  className="flex-1 py-2.5 px-3 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 text-stone-950 font-bold text-xs hover:from-amber-400 hover:to-yellow-300 active:scale-95 transition flex items-center justify-center gap-2 shadow-xs"
                >
                  <ImageIcon className="w-4 h-4" />
                  Elegir foto de la galería
                </button>
              </div>
            )}

            <input
              ref={referenceFileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleReferenceImageUpload}
            />
          </div>

          {/* Header Sunflower Style Customization */}
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Palette className="w-4 h-4 text-amber-600" />
              <label className="text-xs font-bold text-stone-700 uppercase tracking-wide">
                Diseño de Girasoles (Barra Superior)
              </label>
            </div>
            <p className="text-xs text-stone-500 mb-3">
              Personaliza el diseño artístico de girasoles amarillos en la parte superior como en WhatsApp:
            </p>

            <div className="space-y-2">
              {sunflowerStyles.map((item) => {
                const isSelected = headerStyle === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setHeaderStyle(item.id)}
                    className={`w-full text-left p-3 rounded-2xl border transition flex items-center justify-between ${
                      isSelected
                        ? 'border-amber-500 bg-amber-50/80 shadow-xs ring-1 ring-amber-500'
                        : 'border-stone-200 bg-white hover:border-amber-300'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-10 h-10 rounded-xl bg-gradient-to-r ${item.previewColor} flex items-center justify-center text-white text-base shadow-xs`}
                      >
                        🌻
                      </div>
                      <div>
                        <div className="text-xs font-bold text-stone-900">{item.name}</div>
                        <div className="text-[11px] text-stone-500">{item.desc}</div>
                      </div>
                    </div>
                    {isSelected && (
                      <div className="w-6 h-6 rounded-full bg-amber-500 text-stone-950 flex items-center justify-center">
                        <Check className="w-4 h-4 stroke-[3]" />
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Chat Wallpaper Customization */}
          <div className="pt-2 border-t border-stone-200">
            <div className="flex items-center gap-2 mb-2">
              <ImageIcon className="w-4 h-4 text-amber-600" />
              <label className="text-xs font-bold text-stone-700 uppercase tracking-wide">
                Fondo de los Chats (Patrón de Girasoles)
              </label>
            </div>
            <p className="text-xs text-stone-500 mb-3">
              Ajusta la visibilidad del patrón de girasoles amarillos y el tono claro del fondo:
            </p>

            {/* Opacity Slider */}
            <div className="bg-white p-3.5 rounded-2xl border border-stone-200 space-y-2 mb-3">
              <div className="flex justify-between text-xs font-medium text-stone-700">
                <span>Intensidad de girasoles</span>
                <span className="font-bold text-amber-700">
                  {Math.round(chatWallpaperOpacity * 100)}%
                </span>
              </div>
              <input
                type="range"
                min="0.05"
                max="0.45"
                step="0.05"
                value={chatWallpaperOpacity}
                onChange={(e) => setChatWallpaperOpacity(parseFloat(e.target.value))}
                className="w-full accent-amber-500 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-stone-400">
                <span>Muy sutil</span>
                <span>Medio</span>
                <span>Marcado</span>
              </div>
            </div>

            {/* Background colors */}
            <div className="grid grid-cols-2 gap-2">
              {wallpaperBackgrounds.map((bg) => {
                const isSelected = chatWallpaperBg === bg.color;
                return (
                  <button
                    key={bg.color}
                    type="button"
                    onClick={() => setChatWallpaperBg(bg.color)}
                    className={`flex items-center gap-2 p-2.5 rounded-xl border text-xs font-medium transition ${
                      isSelected
                        ? 'border-amber-500 bg-amber-50 text-amber-950 font-bold ring-1 ring-amber-500'
                        : 'border-stone-200 bg-white text-stone-700 hover:border-amber-300'
                    }`}
                  >
                    <span
                      className="w-5 h-5 rounded-full border border-stone-300 shadow-inner"
                      style={{ backgroundColor: bg.color }}
                    />
                    <span className="truncate">{bg.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Conexión con Desarrolladores & Motores IA (Hugging Face / fal.ai / Gemini) */}
          <div className="pt-2 border-t border-stone-200">
            <div className="flex items-center gap-2 mb-2">
              <Cpu className="w-4 h-4 text-amber-600" />
              <label className="text-xs font-bold text-stone-700 uppercase tracking-wide">
                Conexión con Desarrolladores de IA
              </label>
            </div>
            <p className="text-xs text-stone-500 mb-3">
              Selecciona el motor que prefieres para generar tus avatares, escenas y contenido:
            </p>

            <div className="space-y-2">
              {[
                {
                  id: 'auto' as AIEngineProvider,
                  name: '⚡ Automático Inteligente (Recomendado)',
                  desc: 'Combina Gemini Studio, Hugging Face y fal.ai según disponibilidad para la mejor velocidad y calidad.',
                  badge: 'Activo',
                },
                {
                  id: 'gemini' as AIEngineProvider,
                  name: '🌟 Google Gemini Creative Studio',
                  desc: 'Modelo nativo para diseño visual, coherencia estética y chat creativo.',
                  badge: 'Nativo',
                },
                {
                  id: 'huggingface' as AIEngineProvider,
                  name: '🤗 Hugging Face Hub (FLUX.1 / SDXL)',
                  desc: 'Renderizado de alta definición y consistencia de rasgos de personas reales.',
                  badge: 'FLUX / SDXL',
                },
                {
                  id: 'fal' as AIEngineProvider,
                  name: '⚡ fal.ai Pro Engine',
                  desc: 'Inferencia ultra rápida en milisegundos para avatares y estilos LoRA.',
                  badge: 'Ultra Rápido',
                },
              ].map((engine) => {
                const isSelected = aiEngine === engine.id;
                return (
                  <button
                    key={engine.id}
                    type="button"
                    onClick={() => setAiEngine(engine.id)}
                    className={`w-full text-left p-3 rounded-2xl border transition flex items-center justify-between ${
                      isSelected
                        ? 'border-amber-500 bg-amber-50/80 shadow-xs ring-1 ring-amber-500'
                        : 'border-stone-200 bg-white hover:border-amber-300'
                    }`}
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-stone-900">{engine.name}</span>
                        <span className="text-[10px] font-semibold bg-stone-100 text-stone-600 px-2 py-0.5 rounded-full border border-stone-200">
                          {engine.badge}
                        </span>
                      </div>
                      <div className="text-[11px] text-stone-500 mt-0.5">{engine.desc}</div>
                    </div>
                    {isSelected && (
                      <div className="w-6 h-6 rounded-full bg-amber-500 text-stone-950 flex items-center justify-center shrink-0 ml-2">
                        <Check className="w-4 h-4 stroke-[3]" />
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Font Size */}
          <div className="pt-2 border-t border-stone-200">
            <div className="flex items-center gap-2 mb-2">
              <Type className="w-4 h-4 text-amber-600" />
              <label className="text-xs font-bold text-stone-700 uppercase tracking-wide">
                Tamaño del texto en mensajes
              </label>
            </div>
            <div className="grid grid-cols-3 gap-2">
              {(['sm', 'base', 'lg'] as const).map((size) => (
                <button
                  key={size}
                  type="button"
                  onClick={() => setFontSize(size)}
                  className={`py-2 rounded-xl border text-xs font-semibold capitalize transition ${
                    fontSize === size
                      ? 'border-amber-500 bg-amber-500 text-stone-950 shadow-xs'
                      : 'border-stone-200 bg-white text-stone-700 hover:border-amber-300'
                  }`}
                >
                  {size === 'sm' ? 'Pequeño' : size === 'base' ? 'Normal' : 'Grande'}
                </button>
              ))}
            </div>
          </div>

          {/* Data Backup & Management */}
          <div className="pt-2 border-t border-stone-200 space-y-2">
            <label className="text-xs font-bold text-stone-700 uppercase tracking-wide block mb-1">
              Copia de Seguridad y Archivos
            </label>

            <button
              type="button"
              onClick={onExportData}
              className="w-full py-2.5 px-3.5 rounded-xl bg-white hover:bg-stone-100 border border-stone-300 text-stone-800 text-xs font-semibold flex items-center justify-center gap-2 transition"
            >
              <Download className="w-4 h-4 text-amber-600" />
              Exportar todos mis chats y proyectos (Copia de seguridad)
            </button>

            <button
              type="button"
              onClick={() => fileImportRef.current?.click()}
              className="w-full py-2.5 px-3.5 rounded-xl bg-white hover:bg-stone-100 border border-stone-300 text-stone-800 text-xs font-semibold flex items-center justify-center gap-2 transition"
            >
              <Upload className="w-4 h-4 text-amber-600" />
              Restaurar copia de seguridad
            </button>
            <input
              ref={fileImportRef}
              type="file"
              accept=".json"
              className="hidden"
              onChange={handleImportFile}
            />

            <button
              type="button"
              onClick={() => {
                if (
                  window.confirm(
                    '¿Deseas reiniciar la aplicación a su estado inicial limpio? Se borrarán todos los chats y fotos creadas.'
                  )
                ) {
                  onClearData();
                  onClose();
                }
              }}
              className="w-full py-2 px-3 rounded-xl text-red-600 hover:bg-red-50 text-xs font-semibold flex items-center justify-center gap-1.5 transition"
            >
              <Trash2 className="w-3.5 h-3.5" />
              Reiniciar aplicación y vaciar todo
            </button>
          </div>
        </div>

        {/* Save Bar */}
        <div className="p-4 bg-white border-t border-stone-200">
          <button
            onClick={handleSave}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-stone-950 font-bold text-sm hover:from-amber-400 hover:to-yellow-400 active:scale-98 transition flex items-center justify-center gap-2 shadow-md shadow-amber-500/20"
          >
            <Check className="w-4 h-4 stroke-[3]" />
            Guardar ajustes
          </button>
        </div>
      </div>
    </div>
  );
};
