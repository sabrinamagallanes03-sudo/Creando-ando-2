import React, { useState, useRef } from 'react';
import { NovedadItem, UserProfile } from '../types';
import { Plus, Camera, Image as ImageIcon, Share2, Heart, Trash2, X, Sparkles, Tag } from 'lucide-react';
import { ShareModal } from './ShareModal';

interface NovedadesViewProps {
  items: NovedadItem[];
  profile: UserProfile;
  onAddItem: (item: Omit<NovedadItem, 'id' | 'createdAt' | 'likes'>) => void;
  onDeleteItem: (id: string) => void;
  onLikeItem: (id: string) => void;
  onOpenLiveCamera: () => void;
}

export const NovedadesView: React.FC<NovedadesViewProps> = ({
  items,
  profile,
  onAddItem,
  onDeleteItem,
  onLikeItem,
  onOpenLiveCamera,
}) => {
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [selectedShareItem, setSelectedShareItem] = useState<NovedadItem | null>(null);
  const [activeFilter, setActiveFilter] = useState<string>('todos');

  // Form states
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<string>('Avatar Maestro');
  const [mediaUrl, setMediaUrl] = useState('');
  const [priceOrClient, setPriceOrClient] = useState('');
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const categories = [
    'Avatar Maestro',
    'Vestuario',
    'Escenario',
    'Historieta',
    'Video/Miniserie',
    'Sticker',
    'Publicidad',
  ];

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setMediaUrl(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !mediaUrl) {
      alert('Por favor agrega un título y una imagen para tu trabajo.');
      return;
    }

    onAddItem({
      title: title.trim(),
      description: description.trim(),
      category,
      mediaUrl,
      mediaType: 'image',
      priceOrClient: priceOrClient.trim() || undefined,
    });

    setTitle('');
    setDescription('');
    setMediaUrl('');
    setPriceOrClient('');
    setIsCreateModalOpen(false);
  };

  const filteredItems = items.filter((item) => {
    if (activeFilter === 'todos') return true;
    return item.category.toLowerCase().includes(activeFilter.toLowerCase());
  });

  return (
    <div className="flex-1 overflow-y-auto bg-stone-50 pb-20">
      {/* WhatsApp Style Top "Mi Estado / Nuevo Trabajo" Section */}
      <div className="bg-white p-4 border-b border-stone-200">
        <div className="flex items-center justify-between">
          <div
            onClick={() => setIsCreateModalOpen(true)}
            className="flex items-center gap-3.5 cursor-pointer group flex-1"
          >
            <div className="relative">
              <div className="w-14 h-14 rounded-full overflow-hidden border-2 border-dashed border-amber-400 p-0.5 bg-amber-50 flex items-center justify-center text-amber-800 font-bold text-xl">
                {profile.avatarUrl ? (
                  <img src={profile.avatarUrl} alt="Foto" className="w-full h-full object-cover rounded-full" />
                ) : (
                  <span>{profile.name.charAt(0).toUpperCase()}</span>
                )}
              </div>
              <div className="absolute bottom-0 right-0 w-5 h-5 rounded-full bg-gradient-to-r from-amber-500 to-yellow-400 text-stone-950 flex items-center justify-center shadow-md border-2 border-white group-hover:scale-110 transition">
                <Plus className="w-3.5 h-3.5 stroke-[3]" />
              </div>
            </div>

            <div>
              <h3 className="font-bold text-stone-900 text-sm group-hover:text-amber-700 transition">
                Mi estado / Publicar trabajo
              </h3>
              <p className="text-xs text-stone-500">
                Toca para añadir un trabajo que vas realizando
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsCreateModalOpen(true)}
            className="px-3.5 py-1.5 rounded-full bg-amber-500 text-stone-950 font-bold text-xs hover:bg-amber-400 active:scale-95 transition shadow-xs flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5 stroke-[3]" />
            Nuevo
          </button>
        </div>
      </div>

      {/* Category Pills Filter */}
      {items.length > 0 && (
        <div className="px-4 py-3 flex gap-2 overflow-x-auto no-scrollbar bg-stone-100/70 border-b border-stone-200">
          <button
            onClick={() => setActiveFilter('todos')}
            className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition ${
              activeFilter === 'todos'
                ? 'bg-amber-500 text-stone-950 shadow-xs'
                : 'bg-white text-stone-600 hover:bg-stone-200'
            }`}
          >
            Todos ({items.length})
          </button>
          {categories.map((cat) => {
            const count = items.filter((i) => i.category.toLowerCase().includes(cat.toLowerCase())).length;
            if (count === 0) return null;
            return (
              <button
                key={cat}
                onClick={() => setActiveFilter(cat)}
                className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition ${
                  activeFilter === cat
                    ? 'bg-amber-500 text-stone-950 shadow-xs'
                    : 'bg-white text-stone-600 hover:bg-stone-200'
                }`}
              >
                {cat} ({count})
              </button>
            );
          })}
        </div>
      )}

      {/* Works Feed */}
      <div className="p-4 space-y-4 max-w-lg mx-auto">
        {filteredItems.length === 0 ? (
          <div className="py-14 px-6 text-center flex flex-col items-center justify-center bg-white rounded-3xl border border-stone-200/80 shadow-xs">
            <div className="w-20 h-20 rounded-full bg-amber-50 border border-amber-200 flex items-center justify-center text-3xl mb-4 shadow-inner">
              🌻
            </div>
            <h4 className="font-bold text-stone-900 text-base mb-1.5">
              Tus trabajos realizados se verán aquí
            </h4>
            <p className="text-xs text-stone-500 max-w-xs leading-relaxed mb-5">
              Todo el contenido lo vas creando tú. Puedes publicar los avatares, escenas, historietas,
              videos y publicidades que diseñes en el chat o subirlos directamente.
            </p>
            <button
              onClick={() => setIsCreateModalOpen(true)}
              className="px-5 py-2.5 rounded-full bg-gradient-to-r from-amber-500 to-yellow-500 text-stone-950 font-bold text-xs hover:from-amber-400 hover:to-yellow-400 active:scale-95 transition shadow-md shadow-amber-500/20 flex items-center gap-2"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              Publicar mi primer trabajo
            </button>
          </div>
        ) : (
          filteredItems.map((item) => (
            <div
              key={item.id}
              className="bg-white rounded-2xl overflow-hidden border border-stone-200 shadow-xs hover:shadow-md transition duration-200"
            >
              {/* Card Header */}
              <div className="p-3 flex items-center justify-between border-b border-stone-100">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-full bg-amber-100 flex items-center justify-center font-bold text-amber-800 text-xs overflow-hidden">
                    {profile.avatarUrl ? (
                      <img src={profile.avatarUrl} alt="Foto" className="w-full h-full object-cover" />
                    ) : (
                      '🌻'
                    )}
                  </div>
                  <div>
                    <h5 className="font-bold text-stone-900 text-xs">{profile.name}</h5>
                    <span className="text-[10px] text-stone-400">
                      {new Date(item.createdAt).toLocaleDateString([], {
                        day: 'numeric',
                        month: 'short',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold bg-amber-100 text-amber-900 px-2.5 py-0.5 rounded-full border border-amber-200">
                    {item.category}
                  </span>
                  <button
                    onClick={() => {
                      if (window.confirm('¿Deseas eliminar este trabajo de tus Novedades?')) {
                        onDeleteItem(item.id);
                      }
                    }}
                    className="p-1 text-stone-400 hover:text-red-600 rounded-md transition"
                    title="Eliminar"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Media Preview */}
              <div className="relative aspect-square bg-stone-100 overflow-hidden flex items-center justify-center">
                <img
                  src={item.mediaUrl}
                  alt={item.title}
                  className="w-full h-full object-cover"
                  loading="lazy"
                />
              </div>

              {/* Card Body */}
              <div className="p-3.5 space-y-2">
                <div className="flex items-start justify-between gap-2">
                  <h4 className="font-bold text-stone-900 text-sm">{item.title}</h4>
                  {item.priceOrClient && (
                    <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200 shrink-0">
                      {item.priceOrClient}
                    </span>
                  )}
                </div>

                {item.description && (
                  <p className="text-xs text-stone-600 whitespace-pre-line leading-relaxed">
                    {item.description}
                  </p>
                )}

                {/* Card Actions */}
                <div className="pt-2 flex items-center justify-between border-t border-stone-100 text-stone-600">
                  <button
                    onClick={() => onLikeItem(item.id)}
                    className="flex items-center gap-1.5 text-xs hover:text-rose-600 active:scale-95 transition"
                  >
                    <Heart
                      className={`w-4 h-4 ${
                        item.likes > 0 ? 'fill-rose-500 text-rose-500' : 'text-stone-400'
                      }`}
                    />
                    <span className="font-medium">{item.likes > 0 ? item.likes : 'Me gusta'}</span>
                  </button>

                  <button
                    onClick={() => setSelectedShareItem(item)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-amber-50 hover:bg-amber-100 text-amber-800 font-bold text-xs active:scale-95 transition border border-amber-200"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                    Compartir en redes
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Create Work Modal */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="relative w-full max-w-md bg-white rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh] animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between px-5 py-4 bg-gradient-to-r from-amber-600 to-yellow-600 text-white">
              <div className="flex items-center gap-2">
                <span className="text-xl">🌻</span>
                <h3 className="font-bold text-base">Publicar Trabajo en Novedades</h3>
              </div>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="p-1.5 rounded-full hover:bg-white/20 active:scale-95 transition"
              >
                <X className="w-5 h-5 text-white" />
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="p-5 flex-1 overflow-y-auto space-y-4">
              {/* Media Picker */}
              <div>
                <label className="block text-xs font-semibold text-stone-600 uppercase mb-1.5">
                  Foto o creación del trabajo *
                </label>
                {mediaUrl ? (
                  <div className="relative aspect-video rounded-2xl overflow-hidden bg-stone-100 border border-stone-200 group">
                    <img src={mediaUrl} alt="Vista previa" className="w-full h-full object-cover" />
                    <button
                      type="button"
                      onClick={() => setMediaUrl('')}
                      className="absolute top-2 right-2 p-1.5 bg-black/70 text-white rounded-full hover:bg-black transition"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="p-5 rounded-2xl border-2 border-dashed border-stone-300 hover:border-amber-400 bg-stone-50 hover:bg-amber-50/50 flex flex-col items-center justify-center gap-2 text-stone-600 transition"
                    >
                      <ImageIcon className="w-6 h-6 text-amber-600" />
                      <span className="text-xs font-bold">Subir de Galería</span>
                    </button>
                    <button
                      type="button"
                      onClick={onOpenLiveCamera}
                      className="p-5 rounded-2xl border-2 border-dashed border-stone-300 hover:border-amber-400 bg-stone-50 hover:bg-amber-50/50 flex flex-col items-center justify-center gap-2 text-stone-600 transition"
                    >
                      <Camera className="w-6 h-6 text-amber-600" />
                      <span className="text-xs font-bold">Sacar con Cámara</span>
                    </button>
                  </div>
                )}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleFileUpload}
                />
              </div>

              {/* Title */}
              <div>
                <label className="block text-xs font-semibold text-stone-600 uppercase mb-1">
                  Título del trabajo *
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Ej: Avatar 3D Pixar para Sofía"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-500 text-stone-900 text-sm font-medium"
                />
              </div>

              {/* Category */}
              <div>
                <label className="block text-xs font-semibold text-stone-600 uppercase mb-1">
                  Categoría
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-500 text-stone-900 text-sm font-medium bg-white"
                >
                  {categories.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>

              {/* Description */}
              <div>
                <label className="block text-xs font-semibold text-stone-600 uppercase mb-1">
                  Descripción o copy
                </label>
                <textarea
                  rows={3}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Describe la creación, vestuario, estilo o mensaje..."
                  className="w-full px-3.5 py-2 rounded-xl border border-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-500 text-stone-900 text-xs leading-relaxed"
                />
              </div>

              {/* Price or Client note */}
              <div>
                <label className="block text-xs font-semibold text-stone-600 uppercase mb-1">
                  Cliente o Precio (Opcional)
                </label>
                <input
                  type="text"
                  value={priceOrClient}
                  onChange={(e) => setPriceOrClient(e.target.value)}
                  placeholder="Ej: $25 USD / Vendido a Cliente"
                  className="w-full px-3.5 py-2 rounded-xl border border-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-500 text-stone-900 text-xs"
                />
              </div>

              {/* Submit */}
              <div className="pt-2">
                <button
                  type="submit"
                  disabled={!title.trim() || !mediaUrl}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-stone-950 font-bold text-sm hover:from-amber-400 hover:to-yellow-400 active:scale-98 transition flex items-center justify-center gap-2 shadow-md shadow-amber-500/20 disabled:opacity-50"
                >
                  <Plus className="w-4 h-4 stroke-[3]" />
                  Publicar en Novedades
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Share Modal */}
      {selectedShareItem && (
        <ShareModal
          isOpen={Boolean(selectedShareItem)}
          onClose={() => setSelectedShareItem(null)}
          title={selectedShareItem.title}
          text={selectedShareItem.description}
          imageUrl={selectedShareItem.mediaUrl}
        />
      )}
    </div>
  );
};
