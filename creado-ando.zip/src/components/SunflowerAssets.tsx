import React from 'react';
import { HeaderSunflowerStyle, CustomSunflowerConfig } from '../types';

export const defaultSunflowerConfig: CustomSunflowerConfig = {
  petalColor: '#FACC15',
  centerColor: '#451A03',
  bgGradientStart: '#D97706',
  bgGradientEnd: '#F59E0B',
  flowerSize: 'mediano',
  density: 'medio',
  flowerStyle: 'acuarela',
  showLeaves: true,
  opacity: 0.35,
};

export function generateDynamicSunflowerSvg(config?: CustomSunflowerConfig): string {
  const c = config || defaultSunflowerConfig;
  const petal = encodeURIComponent(c.petalColor || '#FACC15');
  const center = encodeURIComponent(c.centerColor || '#451A03');
  const leafColor = '%2365A30D';
  const leafFill = '%2384CC16';

  const isWatercolor = c.flowerStyle === 'acuarela';
  const isMinimalist = c.flowerStyle === 'minimalista';
  const isRadiant = c.flowerStyle === 'radiante';

  return `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="160" height="160" viewBox="0 0 160 160">
  <g fill="none" stroke="${petal}" stroke-width="${isMinimalist ? '1' : '1.5'}" stroke-linecap="round" stroke-linejoin="round" opacity="${c.opacity}">
    <!-- Big Sunflower -->
    <circle cx="36" cy="40" r="14" fill="${petal}" fill-opacity="${isWatercolor ? '0.2' : isMinimalist ? '0.05' : '0.4'}" stroke="${petal}"/>
    <circle cx="36" cy="40" r="6" fill="${center}" fill-opacity="${isMinimalist ? '0.3' : '0.7'}" stroke="${center}"/>
    <path d="M36 22 L36 26 M36 54 L36 58 M18 40 L22 40 M50 40 L54 40 M23 27 L27 30 M45 49 L49 52 M23 53 L27 50 M45 31 L49 28" stroke="${petal}" stroke-width="${isRadiant ? '2.5' : '1.8'}"/>
    <path d="M36 24 C34 20, 38 20, 36 24 M47 28 C50 25, 52 28, 47 31 M52 40 C56 38, 56 42, 52 40 M47 52 C51 55, 48 58, 45 54 M36 56 C38 60, 34 60, 36 56 M25 52 C21 55, 19 52, 23 48 M20 40 C16 42, 16 38, 20 40 M25 28 C22 25, 25 22, 28 26" fill="${petal}" fill-opacity="0.45"/>
    
    ${
      c.showLeaves
        ? `<!-- Leaves -->
    <path d="M36 56 Q30 75 42 90" stroke="${leafColor}" stroke-width="1.4"/>
    <path d="M38 70 Q48 65 44 76 Z" fill="${leafFill}" fill-opacity="0.35" stroke="${leafColor}"/>
    <path d="M34 78 Q22 75 26 84 Z" fill="${leafFill}" fill-opacity="0.35" stroke="${leafColor}"/>`
        : ''
    }

    <!-- Small Sunflower Top-Right -->
    <circle cx="120" cy="30" r="9" fill="${petal}" fill-opacity="0.25" stroke="${petal}"/>
    <circle cx="120" cy="30" r="4" fill="${center}" fill-opacity="0.6" stroke="${center}"/>
    <path d="M120 18 L120 21 M120 39 L120 42 M108 30 L111 30 M129 30 L132 30" stroke="${petal}" stroke-width="1.5"/>
    
    <!-- Medium Sunflower Bottom -->
    <circle cx="105" cy="115" r="12" fill="${petal}" fill-opacity="0.3" stroke="${petal}"/>
    <circle cx="105" cy="115" r="5" fill="${center}" fill-opacity="0.65" stroke="${center}"/>
    <path d="M105 99 L105 103 M105 127 L105 131 M89 115 L93 115 M117 115 L121 115" stroke="${petal}" stroke-width="1.6"/>

    <!-- Delicate sparkles and petals -->
    <circle cx="85" cy="70" r="2.2" fill="${petal}"/>
    <circle cx="68" cy="135" r="1.8" fill="${petal}"/>
    <circle cx="140" cy="60" r="1.6" fill="${petal}"/>
  </g>
</svg>`;
}

export const SUNFLOWER_CHAT_WALLPAPER_SVG = generateDynamicSunflowerSvg();

interface HeaderProps {
  style: HeaderSunflowerStyle;
  customImageUrl?: string;
  customConfig?: CustomSunflowerConfig;
  children: React.ReactNode;
  className?: string;
}

export const SunflowerHeader: React.FC<HeaderProps> = ({
  style,
  customImageUrl,
  customConfig,
  children,
  className = '',
}) => {
  // If user selected custom image
  if (style === 'imagen-personalizada' && customImageUrl) {
    return (
      <div
        className={`relative w-full overflow-hidden text-white shadow-md border-b border-amber-500/40 bg-stone-900 ${className}`}
      >
        <img
          src={customImageUrl}
          alt="Diseño personalizado"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/45 backdrop-blur-[1px]" />
        <div className="relative z-10">{children}</div>
      </div>
    );
  }

  // If user configured custom sunflowers
  if (style === 'girasoles-personalizados' && customConfig) {
    const start = customConfig.bgGradientStart || '#D97706';
    const end = customConfig.bgGradientEnd || '#F59E0B';
    const dynamicPattern = generateDynamicSunflowerSvg(customConfig);

    return (
      <div
        className={`relative w-full overflow-hidden text-white shadow-md border-b border-amber-500/40 ${className}`}
        style={{
          background: `linear-gradient(to right, ${start}, ${end})`,
        }}
      >
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            backgroundImage: `url("${dynamicPattern}")`,
            backgroundRepeat: 'repeat',
            backgroundSize: '160px 160px',
            opacity: customConfig.opacity || 0.35,
          }}
        />
        <div className="relative z-10">{children}</div>
      </div>
    );
  }

  // Renders the vibrant sunflower design pattern across the top WhatsApp bar
  let bgGradient = 'from-amber-600 via-yellow-500 to-amber-700';
  let patternOpacity = 'opacity-35';
  let borderBottomColor = 'border-amber-500/40';

  if (style === 'girasoles-acuarela') {
    bgGradient = 'from-amber-500 via-yellow-400 to-orange-500';
    patternOpacity = 'opacity-40';
    borderBottomColor = 'border-amber-400/50';
  } else if (style === 'girasoles-botanico') {
    bgGradient = 'from-emerald-800 via-amber-600 to-yellow-600';
    patternOpacity = 'opacity-45';
    borderBottomColor = 'border-emerald-600/40';
  } else if (style === 'girasoles-vintage') {
    bgGradient = 'from-amber-800 via-yellow-700 to-amber-900';
    patternOpacity = 'opacity-30';
    borderBottomColor = 'border-amber-600/40';
  } else if (style === 'girasoles-noche') {
    bgGradient = 'from-slate-900 via-amber-950 to-slate-900';
    patternOpacity = 'opacity-50';
    borderBottomColor = 'border-amber-500/30';
  }

  return (
    <div
      className={`relative w-full overflow-hidden text-white shadow-md border-b ${borderBottomColor} bg-gradient-to-r ${bgGradient} ${className}`}
    >
      {/* Dynamic Yellow Sunflowers Vector Pattern Layer */}
      <div
        className={`absolute inset-0 pointer-events-none mix-blend-overlay ${patternOpacity}`}
        style={{
          backgroundImage: `radial-gradient(circle at 10% 20%, rgba(254, 240, 138, 0.4) 0%, transparent 25%),
                            radial-gradient(circle at 85% 70%, rgba(251, 191, 36, 0.45) 0%, transparent 35%)`,
        }}
      />

      {/* Decorative Repeating Yellow Sunflowers Motif */}
      <svg
        className={`absolute inset-0 w-full h-full pointer-events-none ${patternOpacity}`}
        xmlns="http://www.w3.org/2000/svg"
        preserveAspectRatio="xMidYMid slice"
        viewBox="0 0 800 120"
      >
        <defs>
          <g id="header-sunflower">
            {/* Petals */}
            <circle cx="0" cy="0" r="38" fill="#FACC15" />
            <path
              d="M0 -42 C-8 -25, 8 -25, 0 -42 M30 -30 C18 -15, 30 -5, 30 -30 M42 0 C25 -8, 25 8, 42 0 M30 30 C30 5, 18 15, 30 30 M0 42 C8 25, -8 25, 0 42 M-30 30 C-18 15, -30 5, -30 30 M-42 0 C-25 8, -25 -8, -42 0 M-30 -30 C-30 -5, -18 -15, -30 -30"
              fill="#EAB308"
              stroke="#CA8A04"
              strokeWidth="2"
            />
            {/* Inner Ring */}
            <circle cx="0" cy="0" r="22" fill="#B45309" />
            {/* Seed Center */}
            <circle cx="0" cy="0" r="16" fill="#78350F" />
            <circle cx="0" cy="0" r="8" fill="#451A03" />
            {/* Texture Dots */}
            <circle cx="-5" cy="-5" r="1.5" fill="#F59E0B" />
            <circle cx="5" cy="5" r="1.5" fill="#F59E0B" />
            <circle cx="5" cy="-5" r="1.5" fill="#F59E0B" />
            <circle cx="-5" cy="5" r="1.5" fill="#F59E0B" />
          </g>

          <g id="header-leaf">
            <path
              d="M0 0 Q25 -20 50 0 Q25 20 0 0"
              fill="#15803D"
              stroke="#166534"
              strokeWidth="1.5"
            />
            <path d="M0 0 L40 0" stroke="#86EFAC" strokeWidth="1" opacity="0.6" />
          </g>
        </defs>

        {/* Sunflower placements across the header */}
        <use href="#header-leaf" transform="translate(40, 20) rotate(-35) scale(0.7)" />
        <use href="#header-leaf" transform="translate(100, 70) rotate(45) scale(0.6)" />
        <use href="#header-sunflower" transform="translate(60, 45) scale(0.85)" />

        <use href="#header-leaf" transform="translate(250, 30) rotate(-20) scale(0.55)" />
        <use href="#header-sunflower" transform="translate(290, 65) scale(0.65)" />

        <use href="#header-leaf" transform="translate(480, 80) rotate(50) scale(0.6)" />
        <use href="#header-sunflower" transform="translate(520, 35) scale(0.75)" />

        <use href="#header-leaf" transform="translate(710, 15) rotate(-40) scale(0.65)" />
        <use href="#header-sunflower" transform="translate(750, 50) scale(0.9)" />

        {/* Small background floral dust */}
        <circle cx="180" cy="30" r="3" fill="#FEF08A" opacity="0.7" />
        <circle cx="390" cy="80" r="4" fill="#FDE047" opacity="0.6" />
        <circle cx="640" cy="25" r="3" fill="#FDE047" opacity="0.8" />
      </svg>

      {/* Foreground Content with soft contrast backdrop */}
      <div className="relative z-10">{children}</div>
    </div>
  );
};
