import React, { useState, useRef, useEffect } from 'react';
import { Chat, ChatMessage, AppSettings, MasterAvatar } from '../types';
import { SUNFLOWER_CHAT_WALLPAPER_SVG, generateDynamicSunflowerSvg } from './SunflowerAssets';
import {
  ArrowLeft,
  MoreVertical,
  Paperclip,
  Send,
  Camera,
  Image as ImageIcon,
  Sparkles,
  Share2,
  BookmarkPlus,
  Tv,
  CheckCheck,
  Check,
  Smile,
  Mic,
  MicOff,
  X,
  BookOpen,
  Shirt,
  Film,
  Megaphone,
  Sticker,
  Landmark,
  Square,
  Trash2,
  User,
  Eraser,
  Settings,
} from 'lucide-react';
import { ShareModal } from './ShareModal';
import { WhatsAppEmojiPicker } from './WhatsAppEmojiPicker';

interface ChatViewProps {
  chat: Chat;
  settings: AppSettings;
  onBack: () => void;
  onSendMessage: (chatId: string, message: ChatMessage) => void;
  onOpenEditContact: () => void;
  onSaveAsAvatar: (avatar: Omit<MasterAvatar, 'id' | 'createdAt'>) => void;
  onPublishToNovedades: (title: string, description: string, mediaUrl: string, category: string) => void;
  onOpenLiveCamera: () => void;
  onDeleteChat: (chatId: string) => void;
  onClearMessages: (chatId: string) => void;
  onOpenSettings?: () => void;
  onOpenSunflowerCustomizer?: () => void;
  onOpenNovedades?: () => void;
}

export const ChatView: React.FC<ChatViewProps> = ({
  chat,
  settings,
  onBack,
  onSendMessage,
  onOpenEditContact,
  onSaveAsAvatar,
  onPublishToNovedades,
  onOpenLiveCamera,
  onDeleteChat,
  onClearMessages,
  onOpenSettings,
  onOpenSunflowerCustomizer,
  onOpenNovedades,
}) => {
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isAttachmentsOpen, setIsAttachmentsOpen] = useState(false);
  const [isEmojiPickerOpen, setIsEmojiPickerOpen] = useState(false);
  const [isChatMenuOpen, setIsChatMenuOpen] = useState(false);
  const [selectedPhoto, setSelectedPhoto] = useState<string | null>(null);
  const [activeShareData, setActiveShareData] = useState<{ title: string; text?: string; imageUrl?: string } | null>(
    null
  );
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [previewZoomImage, setPreviewZoomImage] = useState<string | null>(null);

  // Voice Recognition State (Web Speech API)
  const [isListening, setIsListening] = useState(false);
  const [voiceSeconds, setVoiceSeconds] = useState(0);
  const recognitionRef = useRef<any>(null);
  const timerRef = useRef<any>(null);
  const baseTextRef = useRef<string>('');

  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (e) {
          // ignore
        }
      }
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, []);

  const startVoiceDictation = () => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      alert(
        'El reconocimiento de voz no está disponible en este navegador. Puedes escribir tu prompt directamente en el campo de texto.'
      );
      return;
    }

    try {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (e) {
          // ignore
        }
      }

      const recognition = new SpeechRecognition();
      recognition.lang = 'es-ES';
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.maxAlternatives = 1;

      baseTextRef.current = inputText ? (inputText.endsWith(' ') ? inputText : inputText + ' ') : '';
      setVoiceSeconds(0);

      recognition.onstart = () => {
        setIsListening(true);
        if (timerRef.current) clearInterval(timerRef.current);
        timerRef.current = setInterval(() => {
          setVoiceSeconds((prev) => prev + 1);
        }, 1000);
      };

      recognition.onresult = (event: any) => {
        let transcript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          transcript += event.results[i][0].transcript;
        }
        if (transcript) {
          setInputText(baseTextRef.current + transcript);
        }
      };

      recognition.onerror = (event: any) => {
        console.warn('Error en reconocimiento de voz:', event.error);
        if (event.error === 'not-allowed') {
          alert('Por favor habilita el permiso de micrófono en tu navegador para dictar tus prompts con la voz.');
        }
        stopVoiceDictation();
      };

      recognition.onend = () => {
        setIsListening(false);
        if (timerRef.current) {
          clearInterval(timerRef.current);
        }
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch (err: any) {
      console.error('Error al iniciar el reconocimiento de voz:', err);
      setIsListening(false);
    }
  };

  const stopVoiceDictation = () => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (e) {
        // ignore
      }
      recognitionRef.current = null;
    }
    setIsListening(false);
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
  };

  const cancelVoiceDictation = () => {
    stopVoiceDictation();
    setInputText(baseTextRef.current.trim());
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chat.messages, isTyping, isGeneratingImage]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setSelectedPhoto(reader.result);
          setIsAttachmentsOpen(false);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSend = async (customPrompt?: string, attachedImg?: string) => {
    const textToSend = customPrompt || inputText;
    const imgToSend = attachedImg || selectedPhoto;

    if (!textToSend.trim() && !imgToSend) return;

    const userMessage: ChatMessage = {
      id: 'msg_' + Date.now(),
      role: 'user',
      content: textToSend.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      image: imgToSend || undefined,
    };

    onSendMessage(chat.id, userMessage);
    setInputText('');
    setSelectedPhoto(null);
    setIsAttachmentsOpen(false);
    setIsTyping(true);

    try {
      // Build conversation history for natural conversational response
      const apiMessages = [...chat.messages, userMessage].map((m) => ({
        role: m.role,
        content: m.content,
        image: m.image,
      }));

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: apiMessages,
          currentChatContext: {
            title: chat.title,
            status: chat.status,
          },
        }),
      });

      if (!response.ok) {
        throw new Error('Error en respuesta del servidor');
      }

      const data = await response.json();
      setIsTyping(false);

      // Assistant message
      const assistantMessage: ChatMessage = {
        id: 'msg_ai_' + Date.now(),
        role: 'assistant',
        content: data.reply || '¡Aquí tienes! ¿Qué te parece esta idea?',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        prompt: data.suggestedPrompt || undefined,
      };

      onSendMessage(chat.id, assistantMessage);

      // If a suggested image prompt was returned, automatically generate the avatar/image
      if (data.suggestedPrompt) {
        generateImageForChat(data.suggestedPrompt, imgToSend || undefined);
      }
    } catch (err: any) {
      console.error('Error enviando mensaje:', err);
      setIsTyping(false);
      const errorMessage: ChatMessage = {
        id: 'msg_err_' + Date.now(),
        role: 'assistant',
        content: 'Hubo un inconveniente al conectar con el asistente creativo. Por favor intenta de nuevo en unos momentos.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      onSendMessage(chat.id, errorMessage);
    }
  };

  const generateImageForChat = async (prompt: string, referenceImage?: string, style?: string) => {
    setIsGeneratingImage(true);
    try {
      const response = await fetch('/api/generate-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          referenceImage,
          style,
          aspectRatio: '1:1',
          provider: settings.aiEngine || 'auto',
        }),
      });

      const data = await response.json();
      setIsGeneratingImage(false);

      if (data.imageUrl) {
        const engineLabel = data.provider ? ` con ${data.provider}` : '';
        const imageMessage: ChatMessage = {
          id: 'msg_img_' + Date.now(),
          role: 'assistant',
          content: `¡Aquí está la creación visual que preparé para ti${engineLabel}! 🌻`,
          image: data.imageUrl,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          isGeneratedAvatar: true,
          prompt,
        };
        onSendMessage(chat.id, imageMessage);
      }
    } catch (e) {
      console.error('Error generando imagen:', e);
      setIsGeneratingImage(false);
    }
  };

  const triggerToolAction = (toolName: string) => {
    setIsAttachmentsOpen(false);
    let prompt = '';
    switch (toolName) {
      case 'maestro':
        prompt =
          'Quiero definir la identidad de mi Avatar Maestro a partir de esta foto. Analiza mis rasgos físicos y crea la ficha técnica de estilo.';
        break;
      case 'vestuario':
        prompt =
          'Diseña 3 nuevas opciones de vestuario creativo para este avatar: uno urbano chic, uno elegante de gala y uno con temática de fantasía.';
        break;
      case 'escenarios':
        prompt =
          'Propón 3 fondos y escenarios cinematográficos para colocar a este avatar (por ejemplo: estudio fotográfico, cafetería acogedora o pasarela moderna).';
        break;
      case 'historieta':
        prompt =
          'Crea el guión para una historieta cómica de 4 viñetas con este avatar, indicando qué se ve en cada cuadro y los diálogos exactos.';
        break;
      case 'video':
        prompt =
          'Desarrolla el guión audiovisual y storyboard para una miniserie o Reel corto de 15 segundos protagonizado por este avatar.';
        break;
      case 'stickers':
        prompt =
          'Diseña un paquete de 6 stickers de WhatsApp con este avatar, mostrando emociones exageradas (sorprendida, enojada, feliz, mandando beso, celebrando).';
        break;
      case 'publicidad':
        prompt =
          'Escribe 2 copys persuasivos con ganchos irresistibles para publicar en WhatsApp e Instagram y vender este tipo de avatares a mis clientes.';
        break;
    }

    if (prompt) {
      handleSend(prompt);
    }
  };

  return (
    <div className="flex flex-col h-full w-full relative overflow-hidden">
      {/* Top Header: WhatsApp Style with Sunflower Theme */}
      <div className="h-16 px-3 bg-gradient-to-r from-amber-600 via-yellow-500 to-amber-600 text-white flex items-center justify-between shadow-md z-20 shrink-0">
        <div className="flex items-center gap-2 flex-1 min-w-0">
          <button
            onClick={onBack}
            className="flex items-center gap-1 py-1 px-2 -ml-1 rounded-full bg-black/15 hover:bg-black/25 active:scale-95 transition shrink-0"
            aria-label="Volver a chats"
            title="Volver a la lista de chats"
          >
            <ArrowLeft className="w-5 h-5 text-white stroke-[2.5]" />
            <span className="text-xs font-bold text-white hidden sm:inline">Chats</span>
          </button>

          {/* Contact Avatar */}
          <div
            onClick={onOpenEditContact}
            className="w-10 h-10 rounded-full overflow-hidden bg-amber-100 border-2 border-white/60 flex items-center justify-center text-amber-900 font-bold text-sm cursor-pointer shadow-xs shrink-0"
          >
            {chat.avatarUrl ? (
              <img src={chat.avatarUrl} alt={chat.title} className="w-full h-full object-cover" />
            ) : (
              <span>{chat.title.charAt(0).toUpperCase() || '🌻'}</span>
            )}
          </div>

          {/* Contact Details */}
          <div
            onClick={onOpenEditContact}
            className="flex-1 min-w-0 cursor-pointer ml-1 text-left"
          >
            <h3 className="font-bold text-sm text-white truncate drop-shadow-xs">{chat.title}</h3>
            <p className="text-[11px] text-amber-100 truncate flex items-center gap-1.5 font-medium">
              {isTyping ? (
                <span className="text-white font-semibold animate-pulse">escribiendo...</span>
              ) : isGeneratingImage ? (
                <span className="text-white font-semibold animate-pulse">creando avatar 🌻...</span>
              ) : (
                <span>{chat.status || 'en línea 🌻'}</span>
              )}
            </p>
          </div>
        </div>

        {/* Action icons */}
        <div className="flex items-center gap-1 text-white relative">
          {/* Direct Sunflower Customizer button */}
          {onOpenSunflowerCustomizer && (
            <button
              onClick={onOpenSunflowerCustomizer}
              className="p-2 rounded-full hover:bg-white/20 active:scale-95 transition"
              title="Diseñar girasoles a mi gusto"
            >
              <span className="text-base leading-none">🌻</span>
            </button>
          )}

          {/* Direct Settings button */}
          {onOpenSettings && (
            <button
              onClick={onOpenSettings}
              className="p-2 rounded-full hover:bg-white/20 active:scale-95 transition"
              title="Ajustes y Personalización"
            >
              <Settings className="w-5 h-5" />
            </button>
          )}

          <button
            onClick={onOpenLiveCamera}
            className="p-2 rounded-full hover:bg-white/20 active:scale-95 transition"
            title="Abrir cámara"
          >
            <Camera className="w-5 h-5" />
          </button>

          <button
            onClick={() => setIsChatMenuOpen(!isChatMenuOpen)}
            className="p-2 rounded-full hover:bg-white/20 active:scale-95 transition"
            title="Más opciones de la conversación"
          >
            <MoreVertical className="w-5 h-5" />
          </button>

          {/* Chat 3-Dots Dropdown Menu */}
          {isChatMenuOpen && (
            <>
              <div
                className="fixed inset-0 z-30"
                onClick={() => setIsChatMenuOpen(false)}
              />
              <div className="absolute right-0 top-11 w-60 bg-white rounded-2xl shadow-2xl py-2 z-40 text-stone-800 border border-stone-200 animate-in fade-in zoom-in-95 duration-150">
                {onOpenSettings && (
                  <button
                    type="button"
                    onClick={() => {
                      setIsChatMenuOpen(false);
                      onOpenSettings();
                    }}
                    className="w-full text-left px-4 py-2.5 hover:bg-amber-50 text-xs font-semibold flex items-center gap-2.5 text-stone-800"
                  >
                    <Settings className="w-4 h-4 text-amber-600" />
                    Ajustes de la aplicación
                  </button>
                )}

                {onOpenSunflowerCustomizer && (
                  <button
                    type="button"
                    onClick={() => {
                      setIsChatMenuOpen(false);
                      onOpenSunflowerCustomizer();
                    }}
                    className="w-full text-left px-4 py-2.5 hover:bg-amber-50 text-xs font-semibold flex items-center gap-2.5 text-stone-800"
                  >
                    <span className="text-base">🌻</span>
                    Diseñar mis girasoles a mi gusto
                  </button>
                )}

                {onOpenNovedades && (
                  <button
                    type="button"
                    onClick={() => {
                      setIsChatMenuOpen(false);
                      onOpenNovedades();
                    }}
                    className="w-full text-left px-4 py-2.5 hover:bg-amber-50 text-xs font-semibold flex items-center gap-2.5 text-stone-800"
                  >
                    <span className="text-base">📢</span>
                    Ir a Actualizaciones / Novedades
                  </button>
                )}

                <div className="h-px bg-stone-100 my-1" />

                <button
                  type="button"
                  onClick={() => {
                    setIsChatMenuOpen(false);
                    onOpenEditContact();
                  }}
                  className="w-full text-left px-4 py-2.5 hover:bg-amber-50 text-xs font-semibold flex items-center gap-2.5 text-stone-800"
                >
                  <User className="w-4 h-4 text-amber-600" />
                  Datos del cliente / contacto
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setIsChatMenuOpen(false);
                    if (
                      window.confirm(
                        `¿Deseas vaciar todos los mensajes de esta conversación con "${chat.title}"?`
                      )
                    ) {
                      onClearMessages(chat.id);
                    }
                  }}
                  className="w-full text-left px-4 py-2.5 hover:bg-amber-50 text-xs font-semibold flex items-center gap-2.5 text-stone-800"
                >
                  <Eraser className="w-4 h-4 text-amber-600" />
                  Vaciar mensajes del chat
                </button>

                <div className="h-px bg-stone-100 my-1" />

                <button
                  type="button"
                  onClick={() => {
                    setIsChatMenuOpen(false);
                    if (
                      window.confirm(
                        `¿Deseas eliminar definitivamente la conversación con "${chat.title}"? Una vez borrada no se podrá recuperar.`
                      )
                    ) {
                      onDeleteChat(chat.id);
                      onBack();
                    }
                  }}
                  className="w-full text-left px-4 py-2.5 hover:bg-red-50 text-xs font-bold flex items-center gap-2.5 text-red-600"
                >
                  <Trash2 className="w-4 h-4 text-red-600" />
                  Eliminar conversación
                </button>
              </div>
            </>
          )}
        </div>
      </div>

      {/* 
        Chat View Body with Subtle Yellow Sunflower Wallpaper Pattern
        "Modifica el CSS de la 'ChatView' para que el fondo de los chats contenga un patrón sutil de girasoles amarillos en lugar de un color sólido, manteniendo la esencia de la interfaz de WhatsApp."
      */}
      <div
        className="flex-1 overflow-y-auto p-3.5 space-y-3 relative chat-sunflower-wallpaper"
        style={{
          backgroundColor: settings.chatWallpaperBg || '#efeae2',
        }}
      >
        {/* Repeating Subtle Yellow Sunflower Pattern Overlay or Custom Design Wallpaper */}
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            backgroundImage: settings.customWallpaperImageUrl
              ? `url("${settings.customWallpaperImageUrl}")`
              : settings.headerStyle === 'girasoles-personalizados' && settings.sunflowerConfig
              ? `url("${generateDynamicSunflowerSvg(settings.sunflowerConfig)}")`
              : `url("${SUNFLOWER_CHAT_WALLPAPER_SVG}")`,
            backgroundRepeat: settings.customWallpaperImageUrl ? 'no-repeat' : 'repeat',
            backgroundPosition: 'center',
            backgroundSize: settings.customWallpaperImageUrl ? 'cover' : '160px 160px',
            opacity: settings.chatWallpaperOpacity ?? 0.18,
          }}
        />

        {/* Foreground Content */}
        <div className="relative z-10 space-y-3 min-h-full flex flex-col justify-end">
          {/* Welcome / Encryption Banner */}
          <div className="mx-auto max-w-xs text-center py-2 px-3 rounded-xl bg-amber-100/90 text-amber-900 border border-amber-200/80 shadow-xs">
            <span className="text-xs font-semibold flex items-center justify-center gap-1">
              🌻 Creado Ando • Estudio Creativo
            </span>
            <p className="text-[11px] text-amber-800/90 mt-0.5 leading-tight">
              Habla naturalmente como con una persona de confianza. Sube una foto o cuéntale tu idea para crear lo que desees.
            </p>
          </div>

          {/* Messages Feed */}
          {chat.messages.map((message) => {
            const isUser = message.role === 'user';
            return (
              <div
                key={message.id}
                className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} animate-in fade-in duration-200`}
              >
                <div
                  className={`max-w-[85%] sm:max-w-md rounded-2xl p-3 shadow-xs relative text-stone-900 ${
                    isUser
                      ? 'bg-[#dcf8c6] rounded-tr-xs text-stone-900'
                      : 'bg-white rounded-tl-xs border border-stone-200/60'
                  }`}
                >
                  {/* Attached photo in message */}
                  {message.image && (
                    <div className="mb-2 rounded-xl overflow-hidden bg-stone-100 border border-stone-200 shadow-xs">
                      <img
                        src={message.image}
                        alt="Adjunto"
                        onClick={() => setPreviewZoomImage(message.image || null)}
                        className="w-full aspect-square object-cover cursor-pointer hover:opacity-95 transition"
                      />

                      {/* Tool buttons for generated avatar images */}
                      {!isUser && (
                        <div className="p-2 bg-stone-50 border-t border-stone-200 space-y-1.5">
                          <div className="grid grid-cols-2 gap-1.5">
                            <button
                              onClick={() => {
                                onSaveAsAvatar({
                                  name: chat.title + ' (Avatar)',
                                  style: 'Avatar Digital',
                                  features: message.prompt || 'Rasgos base',
                                  imageUrl: message.image!,
                                });
                                alert('¡Avatar Maestro guardado exitosamente en tu pestaña de Avatares! 🌻');
                              }}
                              className="py-1 px-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-[11px] flex items-center justify-center gap-1 active:scale-95 transition shadow-xs"
                            >
                              <BookmarkPlus className="w-3.5 h-3.5" />
                              Guardar Avatar
                            </button>

                            <button
                              onClick={() => {
                                onPublishToNovedades(
                                  chat.title + ' • Creación',
                                  message.content,
                                  message.image!,
                                  'Avatar Maestro'
                                );
                                alert('¡Publicado en Novedades con éxito! 🌻');
                              }}
                              className="py-1 px-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] flex items-center justify-center gap-1 active:scale-95 transition shadow-xs"
                            >
                              <Tv className="w-3.5 h-3.5" />
                              Publicar Novedad
                            </button>
                          </div>

                          <div className="flex gap-1.5">
                            <button
                              onClick={() =>
                                setActiveShareData({
                                  title: chat.title,
                                  text: message.content,
                                  imageUrl: message.image,
                                })
                              }
                              className="flex-1 py-1 px-2 rounded-lg border border-stone-300 hover:bg-stone-200 text-stone-700 font-semibold text-[11px] flex items-center justify-center gap-1"
                            >
                              <Share2 className="w-3.5 h-3.5 text-amber-600" />
                              Compartir
                            </button>

                            <button
                              onClick={() =>
                                handleSend(
                                  `Crea una nueva variante de este avatar cambiando su vestuario y estilo.`,
                                  message.image
                                )
                              }
                              className="flex-1 py-1 px-2 rounded-lg border border-stone-300 hover:bg-stone-200 text-stone-700 font-semibold text-[11px] flex items-center justify-center gap-1"
                            >
                              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                              Variante
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Message Text */}
                  <p
                    className={`whitespace-pre-line leading-relaxed text-stone-900 ${
                      settings.fontSize === 'sm'
                        ? 'text-xs'
                        : settings.fontSize === 'lg'
                        ? 'text-base'
                        : 'text-sm'
                    }`}
                  >
                    {message.content}
                  </p>

                  {/* Quick button to generate image if not already present on assistant message */}
                  {!isUser && !message.image && (
                    <div className="mt-2 pt-2 border-t border-stone-100 flex items-center">
                      <button
                        type="button"
                        onClick={() =>
                          generateImageForChat(
                            message.prompt ||
                              `master avatar character portrait, ${message.content.slice(0, 120)}, 3d pixar disney style, vibrant lighting, highly detailed 8k`,
                            selectedPhoto || undefined
                          )
                        }
                        className="py-1 px-2.5 rounded-lg bg-gradient-to-r from-amber-500 to-yellow-400 text-stone-950 font-bold text-[11px] flex items-center gap-1.5 shadow-xs hover:from-amber-400 hover:to-yellow-300 active:scale-95 transition"
                      >
                        <Sparkles className="w-3.5 h-3.5 text-stone-950" />
                        Generar imagen de este avatar ahora 🎨
                      </button>
                    </div>
                  )}

                  {/* Timestamp & double checkmarks */}
                  <div className="flex items-center justify-end gap-1 mt-1 text-[10px] text-stone-500">
                    <span>{message.timestamp}</span>
                    {isUser && <CheckCheck className="w-3.5 h-3.5 text-sky-600 stroke-[2.5]" />}
                  </div>
                </div>
              </div>
            );
          })}

          {/* Typing Indicator */}
          {isTyping && (
            <div className="flex items-center gap-2 p-3 bg-white rounded-2xl rounded-tl-xs border border-stone-200 shadow-xs max-w-xs animate-in fade-in">
              <span className="text-amber-500 animate-spin">🌻</span>
              <span className="text-xs text-stone-500 font-medium">
                El asistente está escribiendo...
              </span>
            </div>
          )}

          {/* Image Generating Indicator */}
          {isGeneratingImage && (
            <div className="flex items-center gap-2 p-3 bg-amber-50 rounded-2xl rounded-tl-xs border border-amber-300 shadow-xs max-w-xs animate-pulse">
              <Sparkles className="w-4 h-4 text-amber-600 animate-spin" />
              <span className="text-xs text-amber-900 font-bold">
                Generando arte del avatar con girasoles...
              </span>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Selected photo preview drawer before sending */}
      {selectedPhoto && (
        <div className="px-3 py-2 bg-stone-100 border-t border-stone-300 flex items-center justify-between z-20">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl overflow-hidden bg-stone-200 border border-stone-300">
              <img src={selectedPhoto} alt="Adjunto" className="w-full h-full object-cover" />
            </div>
            <div className="text-xs font-semibold text-stone-700">Foto lista para enviar</div>
          </div>
          <button
            onClick={() => setSelectedPhoto(null)}
            className="p-1.5 rounded-full hover:bg-stone-200 text-stone-600"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Attachment Menu Popup (WhatsApp Circle Grid) */}
      {isAttachmentsOpen && (
        <div className="p-4 bg-white border-t border-stone-200 shadow-lg z-20 animate-in slide-in-from-bottom-5 duration-200">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-stone-600 uppercase tracking-wide">
              Herramientas de Creado Ando 🌻
            </span>
            <button
              onClick={() => setIsAttachmentsOpen(false)}
              className="p-1 rounded-full text-stone-400 hover:text-stone-700"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-4 gap-3 text-center">
            {/* Cámara */}
            <button
              onClick={() => {
                setIsAttachmentsOpen(false);
                onOpenLiveCamera();
              }}
              className="flex flex-col items-center gap-1 active:scale-95 transition"
            >
              <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-pink-500 to-rose-500 text-white flex items-center justify-center shadow-md">
                <Camera className="w-5 h-5" />
              </div>
              <span className="text-[11px] font-semibold text-stone-700">Cámara</span>
            </button>

            {/* Galería (Subir fotos del celular) */}
            <label
              className="flex flex-col items-center gap-1 active:scale-95 transition cursor-pointer"
              onClick={() => setIsAttachmentsOpen(false)}
            >
              <input
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleFileUpload}
              />
              <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-purple-500 to-indigo-500 text-white flex items-center justify-center shadow-md">
                <ImageIcon className="w-5 h-5" />
              </div>
              <span className="text-[11px] font-semibold text-stone-700">Galería</span>
            </label>

            {/* Avatar Maestro */}
            <button
              onClick={() => triggerToolAction('maestro')}
              className="flex flex-col items-center gap-1 active:scale-95 transition"
            >
              <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-amber-500 to-yellow-400 text-stone-950 flex items-center justify-center shadow-md">
                <span className="text-lg">👑</span>
              </div>
              <span className="text-[11px] font-semibold text-stone-700">Avatar</span>
            </button>

            {/* Vestuario */}
            <button
              onClick={() => triggerToolAction('vestuario')}
              className="flex flex-col items-center gap-1 active:scale-95 transition"
            >
              <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-teal-500 to-emerald-500 text-white flex items-center justify-center shadow-md">
                <Shirt className="w-5 h-5" />
              </div>
              <span className="text-[11px] font-semibold text-stone-700">Vestuario</span>
            </button>

            {/* Escenarios */}
            <button
              onClick={() => triggerToolAction('escenarios')}
              className="flex flex-col items-center gap-1 active:scale-95 transition"
            >
              <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-blue-500 to-cyan-500 text-white flex items-center justify-center shadow-md">
                <Landmark className="w-5 h-5" />
              </div>
              <span className="text-[11px] font-semibold text-stone-700">Escenarios</span>
            </button>

            {/* Historieta */}
            <button
              onClick={() => triggerToolAction('historieta')}
              className="flex flex-col items-center gap-1 active:scale-95 transition"
            >
              <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-orange-500 to-amber-500 text-white flex items-center justify-center shadow-md">
                <BookOpen className="w-5 h-5" />
              </div>
              <span className="text-[11px] font-semibold text-stone-700">Historieta</span>
            </button>

            {/* Video / Miniserie */}
            <button
              onClick={() => triggerToolAction('video')}
              className="flex flex-col items-center gap-1 active:scale-95 transition"
            >
              <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-red-500 to-rose-600 text-white flex items-center justify-center shadow-md">
                <Film className="w-5 h-5" />
              </div>
              <span className="text-[11px] font-semibold text-stone-700">Video</span>
            </button>

            {/* Stickers */}
            <button
              onClick={() => triggerToolAction('stickers')}
              className="flex flex-col items-center gap-1 active:scale-95 transition"
            >
              <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-lime-500 to-green-600 text-white flex items-center justify-center shadow-md">
                <Sticker className="w-5 h-5" />
              </div>
              <span className="text-[11px] font-semibold text-stone-700">Stickers</span>
            </button>
          </div>
        </div>
      )}

      {/* WhatsApp Full Emoji Tray */}
      <WhatsAppEmojiPicker
        isOpen={isEmojiPickerOpen}
        onClose={() => setIsEmojiPickerOpen(false)}
        onSelectEmoji={(emoji) => {
          setInputText((prev) => prev + emoji);
        }}
      />

      {/* Input Bottom Bar (WhatsApp Style) */}
      <div className="p-2 bg-stone-100 border-t border-stone-200 flex items-center gap-2 z-20 shrink-0">
        {isListening ? (
          /* Live Voice Dictation Bar (WhatsApp Voice Note & Speech Recognition style) */
          <div className="flex-1 bg-red-50/90 border border-red-200 rounded-full flex items-center px-4 py-2 gap-3 shadow-inner animate-in fade-in">
            {/* Pulsing red mic indicator */}
            <div className="flex items-center gap-2">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-red-600"></span>
              </span>
              <span className="text-xs font-mono font-bold text-red-700">
                0:{voiceSeconds < 10 ? '0' : ''}{voiceSeconds}
              </span>
            </div>

            {/* Listening Wave / Transcript preview */}
            <div className="flex-1 min-w-0">
              <p className="text-xs text-stone-800 truncate font-medium">
                {inputText ? inputText : '🎙️ Escuchando... Di tu prompt para el avatar'}
              </p>
            </div>

            {/* Cancel Button */}
            <button
              type="button"
              onClick={cancelVoiceDictation}
              className="p-1.5 rounded-full hover:bg-red-100 text-stone-500 hover:text-red-700 transition"
              title="Cancelar dictado"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Finish Dictation Button */}
            <button
              type="button"
              onClick={stopVoiceDictation}
              className="p-1.5 rounded-full bg-red-600 hover:bg-red-700 text-white transition shadow-xs active:scale-95"
              title="Detener y conservar texto"
            >
              <Check className="w-4 h-4 stroke-[3]" />
            </button>
          </div>
        ) : (
          /* Standard Input Bar */
          <div className="flex-1 bg-white rounded-full flex items-center px-3 py-1.5 border border-stone-300 shadow-inner">
            {/* Full WhatsApp Emoji Picker Toggle Button */}
            <button
              type="button"
              onClick={() => {
                setIsAttachmentsOpen(false);
                setIsEmojiPickerOpen(!isEmojiPickerOpen);
              }}
              className={`p-1.5 rounded-full transition ${
                isEmojiPickerOpen
                  ? 'text-amber-600 bg-amber-100 font-bold'
                  : 'text-stone-500 hover:text-amber-600'
              }`}
              title="Emojis de WhatsApp"
            >
              <Smile className="w-5 h-5" />
            </button>

            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  handleSend();
                }
              }}
              placeholder="Mensaje o pulsa el micrófono para dictar..."
              className="flex-1 px-2.5 py-1 text-sm text-stone-900 focus:outline-none bg-transparent placeholder-stone-400"
            />

            {/* Quick voice dictation button inside field */}
            <button
              type="button"
              onClick={startVoiceDictation}
              className="p-1 text-amber-600 hover:text-amber-700 transition active:scale-95"
              title="Dictar prompt por voz"
            >
              <Mic className="w-4 h-4" />
            </button>

            {/* Attachment clip */}
            <button
              type="button"
              onClick={() => {
                setIsEmojiPickerOpen(false);
                setIsAttachmentsOpen(!isAttachmentsOpen);
              }}
              className={`p-1.5 rounded-full transition ${
                isAttachmentsOpen ? 'text-amber-600 bg-amber-50' : 'text-stone-500 hover:text-stone-700'
              }`}
              title="Adjuntar y galería"
            >
              <Paperclip className="w-5 h-5" />
            </button>

            {/* Direct gallery upload button right in the input bar */}
            <label
              className="p-1 text-stone-500 hover:text-amber-600 cursor-pointer active:scale-95 transition"
              title="Subir foto desde el celular"
            >
              <input
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleFileUpload}
              />
              <ImageIcon className="w-5 h-5" />
            </label>

            {/* Direct camera button */}
            <button
              type="button"
              onClick={onOpenLiveCamera}
              className="p-1 text-stone-500 hover:text-amber-600 ml-0.5 active:scale-95 transition"
              title="Tomar foto con la cámara"
            >
              <Camera className="w-5 h-5" />
            </button>
          </div>
        )}

        {/* Send / Mic button */}
        {isListening ? (
          <button
            type="button"
            onClick={() => {
              stopVoiceDictation();
              handleSend();
            }}
            className="w-11 h-11 rounded-full bg-gradient-to-r from-red-500 to-rose-600 text-white flex items-center justify-center shadow-md active:scale-95 transition"
            title="Enviar dictado ahora"
          >
            <Send className="w-5 h-5 stroke-[2.5] ml-0.5" />
          </button>
        ) : inputText.trim() || selectedPhoto ? (
          <button
            type="button"
            onClick={() => handleSend()}
            className="w-11 h-11 rounded-full bg-gradient-to-r from-amber-500 to-yellow-400 text-stone-950 flex items-center justify-center shadow-md active:scale-95 transition"
            title="Enviar mensaje"
          >
            <Send className="w-5 h-5 stroke-[2.5] ml-0.5" />
          </button>
        ) : (
          <button
            type="button"
            onClick={startVoiceDictation}
            className="w-11 h-11 rounded-full bg-gradient-to-r from-amber-500 to-yellow-400 text-stone-950 flex items-center justify-center shadow-md active:scale-95 transition hover:shadow-amber-500/30"
            title="Dictar prompt con micrófono (Reconocimiento de voz)"
          >
            <Mic className="w-5 h-5" />
          </button>
        )}

        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={handleFileUpload}
        />
      </div>

      {/* Fullscreen Photo Zoom Modal */}
      {previewZoomImage && (
        <div
          onClick={() => setPreviewZoomImage(null)}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4 cursor-pointer"
        >
          <div className="relative max-w-lg w-full max-h-[90vh] flex flex-col items-center">
            <button
              onClick={() => setPreviewZoomImage(null)}
              className="absolute top-2 right-2 p-2 bg-black/60 text-white rounded-full hover:bg-black"
            >
              <X className="w-6 h-6" />
            </button>
            <img
              src={previewZoomImage}
              alt="Zoom"
              className="w-full h-auto max-h-[85vh] object-contain rounded-2xl shadow-2xl"
            />
          </div>
        </div>
      )}

      {/* Share Modal */}
      {activeShareData && (
        <ShareModal
          isOpen={Boolean(activeShareData)}
          onClose={() => setActiveShareData(null)}
          title={activeShareData.title}
          text={activeShareData.text}
          imageUrl={activeShareData.imageUrl}
        />
      )}
    </div>
  );
};
