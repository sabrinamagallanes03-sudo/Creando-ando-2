import React, { useState } from 'react';
import { CustomSunflowerConfig, HeaderSunflowerStyle } from '../types';
import { generateDynamicSunflowerSvg, defaultSunflowerConfig } from './SunflowerAssets';
import { X, Check, Sparkles, RefreshCw, Palette, Sliders, Image as ImageIcon, Camera } from 'lucide-react';

interface SunflowerCustomizerModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentConfig?: CustomSunflowerConfig;
  onSave: (config: CustomSunflowerConfig, style: HeaderSunflowerStyle) => void;
  onOpenLiveCamera: () => void;
}

export const SunflowerCustomizerModal: React.FC<SunflowerCustomizerModalProps> = ({
  isOpen,
  onClose,
  currentConfig,
  onSave,
  onOpenLiveCamera,
}) => {
  if (!isOpen) return null;

  const [config, setConfig] = useState<CustomSunflowerConfig>(
    currentConfig || defaultSunflowerConfig
  );
  const [imageUrlInput, setImageUrlInput] = useState('');

  const petalColorPresets = [
    { label: 'Pastel Claro', color: '#FEF08A' },
    { label: 'Amarillo Suave', color: '#FDE047' },
    { label: 'Amarillo Sol', color: '#FACC15' },
    { label: 'Dorado Cálido', color: '#EAB308' },
    { label: 'Ámbar Intenso', color: '#F59E0B' },
    { label: 'Ocre Miel', color: '#D97706' },
  ];

  const centerColorPresets = [
    { label: 'Chocolate Oscuro', color: '#451A03' },
    { label: 'Café Cálido', color: '#78350F' },
    { label: 'Canela', color: '#92400E' },
    { label: 'Dorado Tostado', color: '#B45309' },
  ];

  const bgGradientPresets = [
    { label: 'Dorado Sol', start: '#D97706', end: '#F59E0B' },
    { label: 'Amarillo Suave', start: '#EAB308', end: '#FACC15' },
    { label: 'Crema Lino', start: '#F5F5F4', end: '#E7E5E4' },
    { label: 'Luz Cálida', start: '#FEF3C7', end: '#FDE68A' },
    { label: 'Jardín Suave', start: '#15803D', end: '#CA8A04' },
    { label: 'Noche Brillante', start: '#0F172A', end: '#451A03' },
  ];

  const previewSvg = generateDynamicSunflowerSvg(config);

  const applyPresetStyle = (styleType: 'acuarela' | 'realista' | 'minimalista' | 'radiante' | 'boho') => {
    switch (styleType) {
      case 'acuarela':
        setConfig({
          ...config,
          flowerStyle: 'acuarela',
          petalColor: '#FEF08A',
          centerColor: '#78350F',
          bgGradientStart: '#EAB308',
          bgGradientEnd: '#FACC15',
          opacity: 0.35,
          showLeaves: true,
        });
        break;
      case 'minimalista':
        setConfig({
          ...config,
          flowerStyle: 'minimalista',
          petalColor: '#EAB308',
          centerColor: '#451A03',
          bgGradientStart: '#78350F',
          bgGradientEnd: '#B45309',
          opacity: 0.25,
          showLeaves: false,
        });
        break;
      case 'radiante':
        setConfig({
          ...config,
          flowerStyle: 'radiante',
          petalColor: '#FACC15',
          centerColor: '#451A03',
          bgGradientStart: '#D97706',
          bgGradientEnd: '#F59E0B',
          opacity: 0.45,
          showLeaves: true,
        });
        break;
      case 'boho':
        setConfig({
          ...config,
          flowerStyle: 'boho',
          petalColor: '#D97706',
          centerColor: '#92400E',
          bgGradientStart: '#78350F',
          bgGradientEnd: '#D97706',
          opacity: 0.3,
          showLeaves: true,
        });
        break;
      case 'realista':
        setConfig({
          ...config,
          flowerStyle: 'realista',
          petalColor: '#F59E0B',
          centerColor: '#451A03',
          bgGradientStart: '#B45309',
          bgGradientEnd: '#F59E0B',
          opacity: 0.4,
          showLeaves: true,
        });
        break;
    }
  };

  const handleApply = () => {
    onSave(config, 'girasoles-personalizados');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
      <div className="relative w-full max-w-md bg-stone-50 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh] animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 bg-gradient-to-r from-amber-600 via-yellow-500 to-amber-600 text-white">
          <div className="flex items-center gap-2">
            <span className="text-xl">🌻</span>
            <h3 className="font-bold text-base">Diseñador de Girasoles a Tu Gusto</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 active:scale-95 transition"
          >
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-5 flex-1 overflow-y-auto space-y-5 text-stone-800">
          {/* Live Preview Box */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-stone-700 uppercase tracking-wide flex items-center justify-between">
              <span>Vista previa en vivo</span>
              <span className="text-[10px] text-amber-700 font-semibold">Se actualiza en tiempo real</span>
            </label>

            {/* Simulated WhatsApp Header */}
            <div
              className="rounded-2xl overflow-hidden shadow-md border border-stone-300 relative h-20 flex flex-col justify-between p-3 text-white"
              style={{
                background: `linear-gradient(to right, ${config.bgGradientStart}, ${config.bgGradientEnd})`,
              }}
            >
              <div
                className="absolute inset-0 pointer-events-none"
                style={{
                  backgroundImage: `url("${previewSvg}")`,
                  backgroundRepeat: 'repeat',
                  backgroundSize: '140px 140px',
                  opacity: config.opacity,
                }}
              />
              <div className="relative z-10 flex items-center justify-between">
                <span className="font-extrabold text-sm drop-shadow-sm">Creado Ando</span>
                <span className="text-xs">⋮</span>
              </div>
              <div className="relative z-10 text-[10px] font-bold uppercase tracking-wider flex gap-4 opacity-90">
                <span className="border-b-2 border-white pb-0.5">CHATS</span>
                <span>NOVEDADES</span>
                <span>AVATARES</span>
              </div>
            </div>
          </div>

          {/* Quick Style Presets */}
          <div>
            <label className="text-xs font-bold text-stone-700 uppercase tracking-wide block mb-2">
              Estilo Base del Girasol
            </label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: 'acuarela', label: '🌸 Acuarela Suave & Clara', desc: 'Tonos pasteles y bordes suaves' },
                { id: 'minimalista', label: '✨ Línea Fina Elegante', desc: 'Delicado, limpio y sobrio' },
                { id: 'radiante', label: '☀️ Sol Dorado Radiante', desc: 'Vibrante y lleno de energía' },
                { id: 'boho', label: '🌾 Boho & Mostaza Trigo', desc: 'Tonos cálidos y naturales' },
              ].map((style) => (
                <button
                  key={style.id}
                  type="button"
                  onClick={() => applyPresetStyle(style.id as any)}
                  className={`p-2.5 rounded-xl border text-left transition ${
                    config.flowerStyle === style.id
                      ? 'border-amber-500 bg-amber-500/15 ring-1 ring-amber-500 font-bold'
                      : 'border-stone-200 bg-white hover:border-amber-300'
                  }`}
                >
                  <div className="text-xs text-stone-900 font-bold">{style.label}</div>
                  <div className="text-[10px] text-stone-500 mt-0.5">{style.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Color de Pétalos */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-bold text-stone-700 uppercase tracking-wide flex items-center gap-1.5">
                <Palette className="w-3.5 h-3.5 text-amber-600" />
                Color de los Pétalos
              </label>
              <input
                type="color"
                value={config.petalColor}
                onChange={(e) => setConfig({ ...config, petalColor: e.target.value })}
                className="w-7 h-7 rounded-lg border border-stone-300 cursor-pointer"
                title="Elegir cualquier color"
              />
            </div>
            <div className="grid grid-cols-3 gap-2">
              {petalColorPresets.map((preset) => (
                <button
                  key={preset.color}
                  type="button"
                  onClick={() => setConfig({ ...config, petalColor: preset.color })}
                  className={`p-2 rounded-xl border text-center transition flex items-center gap-2 ${
                    config.petalColor.toLowerCase() === preset.color.toLowerCase()
                      ? 'border-amber-500 bg-amber-50 shadow-xs ring-1 ring-amber-500 font-bold'
                      : 'border-stone-200 bg-white text-stone-700'
                  }`}
                >
                  <span
                    className="w-4 h-4 rounded-full border border-stone-300 shrink-0"
                    style={{ backgroundColor: preset.color }}
                  />
                  <span className="text-[11px] truncate">{preset.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Color del Centro de la Flor */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-bold text-stone-700 uppercase tracking-wide flex items-center gap-1.5">
                <Palette className="w-3.5 h-3.5 text-amber-800" />
                Centro del Girasol
              </label>
              <input
                type="color"
                value={config.centerColor}
                onChange={(e) => setConfig({ ...config, centerColor: e.target.value })}
                className="w-7 h-7 rounded-lg border border-stone-300 cursor-pointer"
                title="Elegir cualquier color"
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              {centerColorPresets.map((preset) => (
                <button
                  key={preset.color}
                  type="button"
                  onClick={() => setConfig({ ...config, centerColor: preset.color })}
                  className={`p-2 rounded-xl border text-center transition flex items-center gap-2 ${
                    config.centerColor.toLowerCase() === preset.color.toLowerCase()
                      ? 'border-amber-500 bg-amber-50 shadow-xs ring-1 ring-amber-500 font-bold'
                      : 'border-stone-200 bg-white text-stone-700'
                  }`}
                >
                  <span
                    className="w-4 h-4 rounded-full border border-stone-300 shrink-0"
                    style={{ backgroundColor: preset.color }}
                  />
                  <span className="text-[11px] truncate">{preset.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Fondo de la Barra Superior */}
          <div>
            <label className="text-xs font-bold text-stone-700 uppercase tracking-wide block mb-2">
              Fondo de la Barra Superior
            </label>
            <div className="grid grid-cols-3 gap-2">
              {bgGradientPresets.map((preset) => {
                const isSelected =
                  config.bgGradientStart === preset.start && config.bgGradientEnd === preset.end;
                return (
                  <button
                    key={preset.label}
                    type="button"
                    onClick={() =>
                      setConfig({ ...config, bgGradientStart: preset.start, bgGradientEnd: preset.end })
                    }
                    className={`p-2 rounded-xl border text-center transition ${
                      isSelected
                        ? 'border-amber-500 bg-amber-50 ring-1 ring-amber-500 font-bold'
                        : 'border-stone-200 bg-white'
                    }`}
                  >
                    <div
                      className="w-full h-4 rounded-md mb-1 shadow-inner"
                      style={{ background: `linear-gradient(to right, ${preset.start}, ${preset.end})` }}
                    />
                    <span className="text-[10px] text-stone-800 truncate block">{preset.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Opciones Adicionales (Hojas y Visibilidad) */}
          <div className="p-3 bg-white rounded-2xl border border-stone-200 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-stone-800">¿Incluir hojitas verdes?</span>
              <button
                type="button"
                onClick={() => setConfig({ ...config, showLeaves: !config.showLeaves })}
                className={`w-12 h-6 rounded-full transition relative p-0.5 ${
                  config.showLeaves ? 'bg-emerald-500' : 'bg-stone-300'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white shadow-md transition transform ${
                    config.showLeaves ? 'translate-x-6' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            <div>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="font-bold text-stone-800">Visibilidad del patrón</span>
                <span className="font-semibold text-stone-500">
                  {Math.round(config.opacity * 100)}%
                </span>
              </div>
              <input
                type="range"
                min="0.1"
                max="0.8"
                step="0.05"
                value={config.opacity}
                onChange={(e) => setConfig({ ...config, opacity: parseFloat(e.target.value) })}
                className="w-full accent-amber-500"
              />
            </div>
          </div>
        </div>

        {/* Save Bar */}
        <div className="p-4 bg-white border-t border-stone-200">
          <button
            onClick={handleApply}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-stone-950 font-bold text-sm hover:from-amber-400 hover:to-yellow-400 active:scale-98 transition flex items-center justify-center gap-2 shadow-md shadow-amber-500/20"
          >
            <Check className="w-4 h-4 stroke-[3]" />
            Guardar mis girasoles personalizados 🌻
          </button>
        </div>
      </div>
    </div>
  );
};
