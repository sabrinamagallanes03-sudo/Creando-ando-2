import React, { useState, useRef } from 'react';
import { UserProfile } from '../types';
import { X, Camera, Check, User, Info, Phone, Instagram } from 'lucide-react';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: UserProfile;
  onSave: (profile: UserProfile) => void;
  onOpenLiveCamera: () => void;
}

export const ProfileModal: React.FC<ProfileModalProps> = ({
  isOpen,
  onClose,
  profile,
  onSave,
  onOpenLiveCamera,
}) => {
  if (!isOpen) return null;

  const [name, setName] = useState(profile.name);
  const [status, setStatus] = useState(profile.status);
  const [socialNetwork, setSocialNetwork] = useState(profile.socialNetwork);
  const [phone, setPhone] = useState(profile.phone);
  const [avatarUrl, setAvatarUrl] = useState(profile.avatarUrl || '');
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setAvatarUrl(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      name: name.trim() || 'Sabrina',
      status: status.trim() || 'Diseñadora de Avatares & Contenido 🌻',
      socialNetwork: socialNetwork.trim(),
      phone: phone.trim(),
      avatarUrl,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
      <div className="relative w-full max-w-sm bg-white rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh] animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 bg-gradient-to-r from-amber-600 via-yellow-500 to-amber-600 text-white">
          <div className="flex items-center gap-2">
            <span className="text-xl">🌻</span>
            <h3 className="font-bold text-base">Perfil de Diseñadora</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 active:scale-95 transition"
          >
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 flex-1 overflow-y-auto space-y-4">
          {/* Avatar edit */}
          <div className="flex flex-col items-center justify-center gap-2 py-2">
            <div className="relative group">
              <div className="w-28 h-28 rounded-full overflow-hidden border-4 border-amber-400 bg-amber-50 shadow-md flex items-center justify-center text-amber-800 font-bold text-3xl">
                {avatarUrl ? (
                  <img src={avatarUrl} alt="Perfil" className="w-full h-full object-cover" />
                ) : (
                  <span>{name.charAt(0).toUpperCase() || 'S'}</span>
                )}
              </div>
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="absolute bottom-1 right-1 p-2.5 bg-amber-500 text-stone-950 rounded-full shadow-lg border-2 border-white hover:bg-amber-400 active:scale-95 transition"
                title="Cambiar foto de perfil"
              >
                <Camera className="w-4 h-4" />
              </button>
            </div>

            <div className="flex items-center gap-3 mt-1">
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="text-xs text-amber-700 hover:text-amber-800 font-semibold underline"
              >
                Subir foto
              </button>
              <span className="text-stone-300">•</span>
              <button
                type="button"
                onClick={onOpenLiveCamera}
                className="text-xs text-amber-700 hover:text-amber-800 font-semibold underline"
              >
                Usar cámara
              </button>
              {avatarUrl && (
                <>
                  <span className="text-stone-300">•</span>
                  <button
                    type="button"
                    onClick={() => setAvatarUrl('')}
                    className="text-xs text-red-600 hover:text-red-700 font-semibold"
                  >
                    Quitar
                  </button>
                </>
              )}
            </div>

            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleFileUpload}
            />
          </div>

          {/* Name Field */}
          <div>
            <label className="block text-xs font-semibold text-stone-600 uppercase mb-1 flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-amber-600" />
              Tu nombre o marca
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Sabrina"
              className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-500 text-stone-900 text-sm font-medium"
            />
          </div>

          {/* Status / Info Field */}
          <div>
            <label className="block text-xs font-semibold text-stone-600 uppercase mb-1 flex items-center gap-1.5">
              <Info className="w-3.5 h-3.5 text-amber-600" />
              Info / Estado
            </label>
            <input
              type="text"
              value={status}
              onChange={(e) => setStatus(e.target.value)}
              placeholder="Diseñadora de Avatares & Contenido 🌻"
              className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-500 text-stone-900 text-sm"
            />
          </div>

          {/* Social Network */}
          <div>
            <label className="block text-xs font-semibold text-stone-600 uppercase mb-1 flex items-center gap-1.5">
              <Instagram className="w-3.5 h-3.5 text-amber-600" />
              Red Social / Instagram / TikTok
            </label>
            <input
              type="text"
              value={socialNetwork}
              onChange={(e) => setSocialNetwork(e.target.value)}
              placeholder="@creadoando"
              className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-500 text-stone-900 text-sm"
            />
          </div>

          {/* Phone */}
          <div>
            <label className="block text-xs font-semibold text-stone-600 uppercase mb-1 flex items-center gap-1.5">
              <Phone className="w-3.5 h-3.5 text-amber-600" />
              Teléfono / WhatsApp de Ventas
            </label>
            <input
              type="text"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="+54 9 11 ..."
              className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-500 text-stone-900 text-sm"
            />
          </div>

          {/* Submit */}
          <div className="pt-2">
            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-stone-950 font-bold text-sm hover:from-amber-400 hover:to-yellow-400 active:scale-98 transition flex items-center justify-center gap-2 shadow-md shadow-amber-500/20"
            >
              <Check className="w-4 h-4 stroke-[3]" />
              Guardar perfil
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
